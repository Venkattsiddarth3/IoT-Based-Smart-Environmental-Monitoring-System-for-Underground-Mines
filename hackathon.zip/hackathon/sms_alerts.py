#!/usr/bin/env python3
"""
SMS Alert System for Underground Mining Monitor
Using Twilio SMS service for easy mobile alerts
"""

import requests
import json
from datetime import datetime

class SMSAlertSystem:
    def __init__(self):
        # Twilio SMS Configuration (Free tier available)
        self.account_sid = "AC1234567890abcdef1234567890abcdef"  # Replace with your Twilio SID
        self.auth_token = "your_auth_token_here"  # Replace with your Twilio Auth Token
        self.from_number = "+1234567890"  # Replace with your Twilio phone number
        
        # Mobile numbers to send alerts to
        self.recipient_numbers = [
            "+919876543210",  # Replace with actual mobile numbers
            "+919876543211"   # Add more numbers as needed
        ]
        
        self.twilio_url = f"https://api.twilio.com/2010-04-01/Accounts/{self.account_sid}/Messages.json"
    
    def send_sms_alert(self, alerts):
        """Send SMS alert for threshold breaches"""
        if not self.account_sid or not self.auth_token:
            print("❌ SMS credentials not configured")
            return False
        
        try:
            # Create SMS message
            message = "🚨 DANGER ALERT - Underground Mining\n\n"
            for alert in alerts:
                message += f"⚠️ {alert['sensor'].upper()}: {alert['value']} (Limit: {alert['threshold']})\n"
            message += f"\nTime: {datetime.now().strftime('%H:%M:%S')}\n"
            message += "Take immediate action!"
            
            print(f"📱 Sending SMS alert to {len(self.recipient_numbers)} numbers...")
            
            # Send SMS to each recipient
            for phone_number in self.recipient_numbers:
                data = {
                    'From': self.from_number,
                    'To': phone_number,
                    'Body': message
                }
                
                response = requests.post(
                    self.twilio_url,
                    data=data,
                    auth=(self.account_sid, self.auth_token),
                    timeout=30
                )
                
                if response.status_code == 201:
                    print(f"✅ SMS sent to {phone_number}")
                else:
                    print(f"❌ Failed to send SMS to {phone_number}: {response.status_code}")
            
            print("📱 SMS alert process completed")
            return True
            
        except Exception as e:
            print(f"❌ Failed to send SMS alert: {e}")
            return False

def test_sms_system():
    """Test SMS alert system"""
    print("📱 TESTING SMS ALERT SYSTEM")
    print("=" * 40)
    
    # Test data
    test_alerts = [
        {
            'sensor': 'temperature',
            'value': 27.5,
            'threshold': 26.0,
            'timestamp': datetime.now().isoformat()
        }
    ]
    
    sms_system = SMSAlertSystem()
    
    print("📋 SMS Configuration:")
    print(f"   From: {sms_system.from_number}")
    print(f"   To: {sms_system.recipient_numbers}")
    print()
    
    print("🧪 Sending test SMS...")
    success = sms_system.send_sms_alert(test_alerts)
    
    if success:
        print("✅ SMS test completed!")
    else:
        print("❌ SMS test failed!")
    
    return success

def show_twilio_setup():
    """Show Twilio setup instructions"""
    print("\n📱 TWILIO SMS SETUP GUIDE")
    print("=" * 35)
    print("1. 🌐 Go to: https://www.twilio.com/")
    print("2. 📝 Sign up for free account")
    print("3. 🔑 Get Account SID and Auth Token")
    print("4. 📞 Get a Twilio phone number (free)")
    print("5. 📝 Update sms_alerts.py with your credentials")
    print("6. 📱 Add recipient mobile numbers")
    print()
    print("💰 COST: Free tier includes 1 SMS per day")
    print("📱 EASY: No complex authentication like Gmail")

if __name__ == "__main__":
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📱 SMS ALERT SYSTEM")
    print("=" * 50)
    
    show_twilio_setup()
    test_sms_system()
