#!/usr/bin/env python3
"""
Gmail App Password Setup Guide - Step by Step
"""

def show_app_password_guide():
    """Show detailed Gmail App Password setup"""
    print("🔑 GMAIL APP PASSWORD SETUP GUIDE")
    print("=" * 50)
    print("Since rangajal@gitam.in already has 2-step verification:")
    print()
    print("📋 STEP-BY-STEP INSTRUCTIONS:")
    print("-" * 30)
    print("1. 🌐 Go to: https://myaccount.google.com/")
    print("2. 🔐 Sign in with: rangajal@gitam.in")
    print("3. ⚙️  Click 'Security' in the left menu")
    print("4. 🔍 Look for 'App passwords' section")
    print("5. 📱 Click 'App passwords'")
    print("6. 📝 Select 'Mail' from the dropdown")
    print("7. 📋 Copy the 16-character password")
    print("8. ✅ Use this password in your mining monitor")
    print()
    print("📝 EXAMPLE APP PASSWORD:")
    print("   Format: 'abcd efgh ijkl mnop'")
    print("   Use as: 'abcdefghijklmnop' (remove spaces)")
    print()
    print("🔧 AFTER GETTING APP PASSWORD:")
    print("1. Update the password in your system")
    print("2. Run: python3 test_email_simple.py")
    print("3. Check if emails are received")
    print("4. Start the main system: python3 run.py")

def create_env_file():
    """Create .env file template"""
    print("\n📄 CREATING .env FILE TEMPLATE:")
    print("-" * 35)
    
    env_content = """# Email Configuration
EMAIL_SMTP_SERVER=smtp.gmail.com
EMAIL_SMTP_PORT=587
EMAIL_USER=rangajal@gitam.in
EMAIL_PASSWORD=YOUR_16_CHARACTER_APP_PASSWORD_HERE
RECIPIENT_EMAILS=sgnana@gitam.in,vnuggu@gitam.in

# Telegram Configuration
TELEGRAM_BOT_TOKEN=8387035130
TELEGRAM_CHAT_ID=y8387035130:AAFlRy0W7e7NvdbFdcF5VW6k_X_m4Gzl8cc
"""
    
    print("📝 Create a file named '.env' with this content:")
    print("   (Replace YOUR_16_CHARACTER_APP_PASSWORD_HERE with your actual App Password)")
    print()
    print("📄 .env file content:")
    print("-" * 20)
    print(env_content)

def test_after_setup():
    """Show what to do after getting App Password"""
    print("\n🧪 TESTING AFTER SETUP:")
    print("-" * 25)
    print("1. 📝 Update .env file with your App Password")
    print("2. 🧪 Run: python3 test_email_simple.py")
    print("3. 📧 Check if test email is received")
    print("4. 🚀 Start main system: python3 run.py")
    print("5. 🌐 Open: http://localhost:5001")
    print("6. 🎯 Temperature threshold is set to 26°C")
    print("7. 📧 Emails will be sent when temperature > 26°C")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 GMAIL APP PASSWORD SETUP")
    print("=" * 50)
    print()
    print("✅ rangajal@gitam.in has 2-step verification enabled")
    print("🔑 Now you need to generate an App Password")
    print()
    
    show_app_password_guide()
    create_env_file()
    test_after_setup()
    
    print("\n" + "=" * 50)
    print("🎯 SUMMARY:")
    print("1. Get App Password from Gmail")
    print("2. Update .env file")
    print("3. Test email system")
    print("4. Start mining monitor")
    print("5. Emails will be sent to sgnana@gitam.in and vnuggu@gitam.in")

if __name__ == "__main__":
    main()
