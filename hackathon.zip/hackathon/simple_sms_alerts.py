#!/usr/bin/env python3
"""
Simple SMS Alert System using free SMS services
No complex setup required - just mobile numbers
"""

import requests
import json
from datetime import datetime

class SimpleSMSAlert:
    def __init__(self):
        # Using TextBelt (free SMS service) - 1 free SMS per day
        self.api_key = "textbelt"  # Free tier
        self.api_url = "https://textbelt.com/text"
        
        # Mobile numbers to send alerts to (with country code)
        self.recipient_numbers = [
            "+919876543210",  # Replace with actual mobile numbers
            "+919876543211"   # Add more numbers as needed
        ]
    
    def send_sms_alert(self, alerts):
        """Send SMS alert for threshold breaches"""
        try:
            # Create SMS message
            message = "🚨 DANGER ALERT - Underground Mining\n\n"
            for alert in alerts:
                message += f"⚠️ {alert['sensor'].upper()}: {alert['value']} (Limit: {alert['threshold']})\n"
            message += f"\nTime: {datetime.now().strftime('%H:%M:%S')}\n"
            message += "Take immediate action!"
            
            print(f"📱 Sending SMS alert to {len(self.recipient_numbers)} numbers...")
            
            # Send SMS to each recipient
            for phone_number in self.recipient_numbers:
                data = {
                    'phone': phone_number,
                    'message': message,
                    'key': self.api_key
                }
                
                response = requests.post(self.api_url, data=data, timeout=30)
                
                if response.status_code == 200:
                    result = response.json()
                    if result.get('success'):
                        print(f"✅ SMS sent to {phone_number}")
                    else:
                        print(f"❌ Failed to send SMS to {phone_number}: {result.get('error', 'Unknown error')}")
                else:
                    print(f"❌ HTTP error {response.status_code} for {phone_number}")
            
            print("📱 SMS alert process completed")
            return True
            
        except Exception as e:
            print(f"❌ Failed to send SMS alert: {e}")
            return False

def test_sms_system():
    """Test SMS alert system"""
    print("📱 TESTING SIMPLE SMS ALERT SYSTEM")
    print("=" * 45)
    
    # Test data
    test_alerts = [
        {
            'sensor': 'temperature',
            'value': 27.5,
            'threshold': 26.0,
            'timestamp': datetime.now().isoformat()
        }
    ]
    
    sms_system = SimpleSMSAlert()
    
    print("📋 SMS Configuration:")
    print(f"   Service: TextBelt (Free)")
    print(f"   Recipients: {sms_system.recipient_numbers}")
    print()
    
    print("🧪 Sending test SMS...")
    success = sms_system.send_sms_alert(test_alerts)
    
    if success:
        print("✅ SMS test completed!")
    else:
        print("❌ SMS test failed!")
    
    return success

def show_mobile_numbers_setup():
    """Show how to add mobile numbers"""
    print("\n📱 MOBILE NUMBERS SETUP")
    print("=" * 30)
    print("1. 📝 Edit simple_sms_alerts.py")
    print("2. 🔄 Replace the recipient_numbers list:")
    print("   self.recipient_numbers = [")
    print("       '+919876543210',  # Your mobile number")
    print("       '+919876543211'   # Another mobile number")
    print("   ]")
    print("3. 📱 Use format: +91XXXXXXXXXX (with country code)")
    print("4. 🧪 Test: python3 simple_sms_alerts.py")
    print()
    print("💰 COST: Free (1 SMS per day per number)")
    print("🚀 EASY: No complex authentication required")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📱 SIMPLE SMS ALERT SYSTEM")
    print("=" * 50)
    
    show_mobile_numbers_setup()
    test_sms_system()

if __name__ == "__main__":
    main()
