from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO, emit
import paho.mqtt.client as mqtt
import json
import sqlite3
import threading
import time
from datetime import datetime
import requests
import os
from dotenv import load_dotenv
from email_alerts import EmailAlertSystem

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
socketio = SocketIO(app, cors_allowed_origins="*")

# MQTT Configuration
MQTT_SERVER = "c2d3d6cc30c0464cbfb2273abea14ca6.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USER = "Rahul_Tej123"
MQTT_PASSWORD = "SMDRizwan9"
MQTT_TOPIC = "mine/sensors/data"

# Sensor Thresholds (Danger Levels) - Updated based on actual data
THRESHOLDS = {
    'mq2_gas': 50.0,      # ppm - Methane, LPG, Propane
    'mq9_gas': 30.0,      # ppm - CO, LPG, CH4
    'temperature': 26.0,   # °C - High temperature (DEMO: Set to 26°C for email demo)
    'humidity': 90.0,      # % - High humidity
    'noise': 50.0          # dB - High noise level
}

# Alert Configuration
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')
EMAIL_SMTP_SERVER = os.getenv('EMAIL_SMTP_SERVER', 'smtp.gmail.com')
EMAIL_SMTP_PORT = int(os.getenv('EMAIL_SMTP_PORT', '587'))
EMAIL_USER = os.getenv('EMAIL_USER', '')
EMAIL_PASSWORD = os.getenv('EMAIL_PASSWORD', '')

# Database setup
def init_database():
    conn = sqlite3.connect('sensor_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sensor_readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            mq2_gas REAL,
            mq9_gas REAL,
            temperature REAL,
            humidity REAL,
            noise REAL,
            mq2_alert INTEGER,
            mq9_alert INTEGER
        )
    ''')
    conn.commit()
    conn.close()

# MQTT Client Setup
class MQTTClient:
    def __init__(self):
        self.client = mqtt.Client()
        self.client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
        self.client.tls_set()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.last_readings = {}
        
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print("✅ Connected to HiveMQ Cloud!")
            print(f"📡 Subscribing to topic: {MQTT_TOPIC}")
            client.subscribe(MQTT_TOPIC)
            # Emit connection status to web clients
            socketio.emit('mqtt_status', {'connected': True})
        else:
            print(f"❌ Failed to connect to HiveMQ, return code {rc}")
            socketio.emit('mqtt_status', {'connected': False, 'error': f'Connection failed: {rc}'})
    
    def on_message(self, client, userdata, msg):
        try:
            raw_data = json.loads(msg.payload.decode())
            timestamp = datetime.now().strftime("%H:%M:%S")
            
            # Convert your data format to our expected format
            data = {
                'mq2_gas': raw_data.get('MQ2', 0),
                'mq9_gas': raw_data.get('MQ9', 0),
                'temperature': raw_data.get('Temperature', 0),
                'humidity': raw_data.get('Humidity', 0),
                'noise': raw_data.get('Noise', 0),
                'mq2_alert': raw_data.get('MQ2Alert', 0),
                'mq9_alert': raw_data.get('MQ9Alert', 0)
            }
            
            print(f"📊 [{timestamp}] Received sensor data:")
            print(f"   MQ2 Gas: {data['mq2_gas']} ppm (Alert: {data['mq2_alert']})")
            print(f"   MQ9 Gas: {data['mq9_gas']} ppm (Alert: {data['mq9_alert']})")
            print(f"   Temperature: {data['temperature']} °C")
            print(f"   Humidity: {data['humidity']} %")
            print(f"   Noise: {data['noise']} dB")
            print("   ✅ Sending to web UI...")
            
            # Store in database
            self.store_data(data)
            
            # Update last readings
            self.last_readings = data
            
            # Emit to web clients
            socketio.emit('sensor_data', data)
            
            # Check thresholds and send alerts
            self.check_thresholds(data)
            
        except Exception as e:
            print(f"❌ Error processing message: {e}")
    
    def store_data(self, data):
        conn = sqlite3.connect('sensor_data.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sensor_readings 
            (mq2_gas, mq9_gas, temperature, humidity, noise, mq2_alert, mq9_alert)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('mq2_gas', 0),
            data.get('mq9_gas', 0),
            data.get('temperature', 0),
            data.get('humidity', 0),
            data.get('noise', 0),
            data.get('mq2_alert', 0),
            data.get('mq9_alert', 0)
        ))
        conn.commit()
        conn.close()
    
    def check_thresholds(self, data):
        alerts = []
        
        for sensor, value in data.items():
            if sensor in THRESHOLDS and value > THRESHOLDS[sensor]:
                alerts.append({
                    'sensor': sensor,
                    'value': value,
                    'threshold': THRESHOLDS[sensor],
                    'timestamp': datetime.now().isoformat()
                })
        
        if alerts:
            self.send_alerts(alerts)
            socketio.emit('alert', {'alerts': alerts})
    
    def send_alerts(self, alerts):
        # Send Telegram alert
        if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
            self.send_telegram_alert(alerts)
        
        # Send Email alert
        if EMAIL_USER and EMAIL_PASSWORD:
            self.send_email_alert(alerts)
        
        # Send SMS alert
        self.send_sms_alert(alerts)
    
    def send_telegram_alert(self, alerts):
        message = "🚨 DANGER ALERT - Underground Mining Environment\n\n"
        for alert in alerts:
            message += f"⚠️ {alert['sensor'].upper()}: {alert['value']} (Threshold: {alert['threshold']})\n"
        message += f"\nTime: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {
            'chat_id': TELEGRAM_CHAT_ID,
            'text': message
        }
        
        try:
            requests.post(url, data=data)
            print("Telegram alert sent successfully")
        except Exception as e:
            print(f"Failed to send Telegram alert: {e}")
    
    def send_email_alert(self, alerts):
        # Use the email alert system
        try:
            print("📧 Attempting to send email alert...")
            success = email_system.send_alert(alerts)
            if success:
                print("✅ Email alert sent successfully")
            else:
                print("❌ Email alert failed - check configuration")
        except Exception as e:
            print(f"❌ Email alert error: {e}")
            print("📧 Email alerts are configured but may need authentication setup")
    
    def send_sms_alert(self, alerts):
        """Send SMS alert for threshold breaches"""
        try:
            # Create SMS message
            message = "🚨 DANGER ALERT - Underground Mining\n\n"
            for alert in alerts:
                message += f"⚠️ {alert['sensor'].upper()}: {alert['value']} (Limit: {alert['threshold']})\n"
            message += f"\nTime: {datetime.now().strftime('%H:%M:%S')}\n"
            message += "Take immediate action!"
            
            # Mobile numbers to send alerts to (with country code)
            recipient_numbers = [
                "+919876543210",  # Replace with actual mobile numbers
                "+919876543211"   # Add more numbers as needed
            ]
            
            print(f"📱 Sending SMS alert to {len(recipient_numbers)} numbers...")
            
            # Using TextBelt free SMS service
            for phone_number in recipient_numbers:
                data = {
                    'phone': phone_number,
                    'message': message,
                    'key': 'textbelt'  # Free tier
                }
                
                response = requests.post('https://textbelt.com/text', data=data, timeout=30)
                
                if response.status_code == 200:
                    result = response.json()
                    if result.get('success'):
                        print(f"✅ SMS sent to {phone_number}")
                    else:
                        print(f"❌ Failed to send SMS to {phone_number}: {result.get('error', 'Unknown error')}")
                else:
                    print(f"❌ HTTP error {response.status_code} for {phone_number}")
            
            print("📱 SMS alert process completed")
            
        except Exception as e:
            print(f"❌ Failed to send SMS alert: {e}")
    
    def connect(self):
        try:
            print(f"🔗 Connecting to HiveMQ Cloud: {MQTT_SERVER}:{MQTT_PORT}")
            self.client.connect(MQTT_SERVER, MQTT_PORT, 60)
            self.client.loop_start()
        except Exception as e:
            print(f"❌ MQTT connection error: {e}")
            socketio.emit('mqtt_status', {'connected': False, 'error': str(e)})

# Initialize MQTT client and email system
mqtt_client = MQTTClient()
email_system = EmailAlertSystem()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/current_data')
def get_current_data():
    return jsonify(mqtt_client.last_readings)

@app.route('/api/historical_data')
def get_historical_data():
    conn = sqlite3.connect('sensor_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM sensor_readings 
        ORDER BY timestamp DESC 
        LIMIT 100
    ''')
    data = cursor.fetchall()
    conn.close()
    
    # Convert to list of dictionaries
    historical_data = []
    for row in data:
        historical_data.append({
            'id': row[0],
            'timestamp': row[1],
            'mq2_gas': row[2],
            'mq9_gas': row[3],
            'heart_rate': row[4],
            'temperature': row[5],
            'humidity': row[6],
            'noise': row[7]
        })
    
    return jsonify(historical_data)

@app.route('/api/thresholds')
def get_thresholds():
    return jsonify(THRESHOLDS)

# WebSocket event handlers
@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('status', {'connected': True})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@socketio.on('request_status')
def handle_status_request():
    mqtt_status = mqtt_client.client.is_connected() if mqtt_client.client else False
    emit('status', {
        'connected': True, 
        'mqtt_connected': mqtt_status,
        'server': 'HiveMQ Cloud',
        'last_data': mqtt_client.last_readings
    })

if __name__ == '__main__':
    init_database()
    mqtt_client.connect()
    
    # Try different ports if 5000 is busy
    ports_to_try = [5000, 5001, 5002, 5003, 5004]
    
    for port in ports_to_try:
        try:
            print(f"🌐 Starting web server on port {port}...")
            socketio.run(app, debug=False, host='0.0.0.0', port=port)
            break
        except OSError as e:
            if "Address already in use" in str(e):
                print(f"❌ Port {port} is busy, trying next port...")
                continue
            else:
                print(f"❌ Error: {e}")
                break
    else:
        print("❌ All ports are busy. Please free up a port or restart your system.")
