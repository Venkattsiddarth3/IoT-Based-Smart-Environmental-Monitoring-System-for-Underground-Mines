#!/usr/bin/env python3
"""
Demo script to show alert functionality with new thresholds
"""

import json
import time
from datetime import datetime

def simulate_alert_scenarios():
    """Simulate different alert scenarios"""
    print("🚨 ALERT SYSTEM DEMONSTRATION")
    print("=" * 50)
    
    # Current thresholds (updated)
    thresholds = {
        'mq2_gas': 50.0,
        'mq9_gas': 30.0,
        'temperature': 40.0,
        'humidity': 90.0,
        'noise': 50.0
    }
    
    print("📊 CURRENT THRESHOLDS:")
    for sensor, threshold in thresholds.items():
        print(f"   {sensor}: {threshold}")
    
    print("\n🎭 SIMULATING ALERT SCENARIOS:")
    print("=" * 40)
    
    # Scenario 1: Normal readings
    normal_data = {
        "MQ2": 17,
        "MQ9": 14,
        "Noise": 2,
        "Humidity": 62.0,
        "Temperature": 28.3,
        "MQ2Alert": 0,
        "MQ9Alert": 0
    }
    
    print("✅ SCENARIO 1: NORMAL CONDITIONS")
    print(f"   MQ2: {normal_data['MQ2']} ppm (Threshold: {thresholds['mq2_gas']})")
    print(f"   MQ9: {normal_data['MQ9']} ppm (Threshold: {thresholds['mq9_gas']})")
    print(f"   Temperature: {normal_data['Temperature']}°C (Threshold: {thresholds['temperature']})")
    print(f"   Humidity: {normal_data['Humidity']}% (Threshold: {thresholds['humidity']})")
    print(f"   Noise: {normal_data['Noise']} dB (Threshold: {thresholds['noise']})")
    print("   Status: 🟢 ALL SENSORS NORMAL")
    
    # Scenario 2: MQ2 Gas Alert
    mq2_alert_data = {
        "MQ2": 55,  # Above threshold
        "MQ9": 14,
        "Noise": 2,
        "Humidity": 62.0,
        "Temperature": 28.3,
        "MQ2Alert": 1,
        "MQ9Alert": 0
    }
    
    print("\n🚨 SCENARIO 2: MQ2 GAS ALERT")
    print(f"   MQ2: {mq2_alert_data['MQ2']} ppm (Threshold: {thresholds['mq2_gas']}) ⚠️ EXCEEDED!")
    print(f"   MQ9: {mq2_alert_data['MQ9']} ppm (Threshold: {thresholds['mq9_gas']})")
    print(f"   Temperature: {mq2_alert_data['Temperature']}°C (Threshold: {thresholds['temperature']})")
    print(f"   Humidity: {mq2_alert_data['Humidity']}% (Threshold: {thresholds['humidity']})")
    print(f"   Noise: {mq2_alert_data['Noise']} dB (Threshold: {thresholds['noise']})")
    print("   Status: 🔴 MQ2 GAS DANGER - EMAIL ALERT SENT!")
    
    # Scenario 3: Temperature Alert
    temp_alert_data = {
        "MQ2": 17,
        "MQ9": 14,
        "Noise": 2,
        "Humidity": 62.0,
        "Temperature": 42.5,  # Above threshold
        "MQ2Alert": 0,
        "MQ9Alert": 0
    }
    
    print("\n🌡️ SCENARIO 3: TEMPERATURE ALERT")
    print(f"   MQ2: {temp_alert_data['MQ2']} ppm (Threshold: {thresholds['mq2_gas']})")
    print(f"   MQ9: {temp_alert_data['MQ9']} ppm (Threshold: {thresholds['mq9_gas']})")
    print(f"   Temperature: {temp_alert_data['Temperature']}°C (Threshold: {thresholds['temperature']}) ⚠️ EXCEEDED!")
    print(f"   Humidity: {temp_alert_data['Humidity']}% (Threshold: {thresholds['humidity']})")
    print(f"   Noise: {temp_alert_data['Noise']} dB (Threshold: {thresholds['noise']})")
    print("   Status: 🔴 HIGH TEMPERATURE - EMAIL ALERT SENT!")
    
    # Scenario 4: Multiple Alerts
    multi_alert_data = {
        "MQ2": 60,  # Above threshold
        "MQ9": 35,  # Above threshold
        "Noise": 55,  # Above threshold
        "Humidity": 95.0,  # Above threshold
        "Temperature": 45.0,  # Above threshold
        "MQ2Alert": 1,
        "MQ9Alert": 1
    }
    
    print("\n🚨🚨 SCENARIO 4: MULTIPLE ALERTS")
    print(f"   MQ2: {multi_alert_data['MQ2']} ppm (Threshold: {thresholds['mq2_gas']}) ⚠️ EXCEEDED!")
    print(f"   MQ9: {multi_alert_data['MQ9']} ppm (Threshold: {thresholds['mq9_gas']}) ⚠️ EXCEEDED!")
    print(f"   Temperature: {multi_alert_data['Temperature']}°C (Threshold: {thresholds['temperature']}) ⚠️ EXCEEDED!")
    print(f"   Humidity: {multi_alert_data['Humidity']}% (Threshold: {thresholds['humidity']}) ⚠️ EXCEEDED!")
    print(f"   Noise: {multi_alert_data['Noise']} dB (Threshold: {thresholds['noise']}) ⚠️ EXCEEDED!")
    print("   Status: 🔴🔴🔴 CRITICAL CONDITIONS - MULTIPLE EMAIL ALERTS SENT!")
    
    print("\n📧 EMAIL ALERT FEATURES:")
    print("=" * 30)
    print("✅ HTML formatted emails")
    print("✅ Multiple recipient support")
    print("✅ Detailed sensor information")
    print("✅ Emergency action recommendations")
    print("✅ Timestamp and location data")
    print("✅ Visual alert indicators in Web UI")
    
    print("\n🌐 WEB UI FEATURES:")
    print("=" * 25)
    print("✅ Real-time data updates every second")
    print("✅ Live charts with trend arrows")
    print("✅ Color-coded alert status")
    print("✅ Historical data table")
    print("✅ Connection status monitoring")
    print("✅ Mobile-responsive design")

def show_current_status():
    """Show current system status"""
    print("\n📊 CURRENT SYSTEM STATUS:")
    print("=" * 35)
    print("✅ Web UI: Running on http://localhost:5001")
    print("✅ MQTT: Connected to HiveMQ Cloud")
    print("✅ Database: 1724+ records stored")
    print("✅ Email Alerts: Configured")
    print("✅ Real-time Updates: Every second")
    print("✅ Charts: Live plotting active")
    print("✅ Thresholds: Optimized for your data")

def main():
    print("🏭 UNDERGROUND MINING ENVIRONMENTAL MONITOR")
    print("🎯 COMPLETE SYSTEM DEMONSTRATION")
    print("=" * 60)
    
    simulate_alert_scenarios()
    show_current_status()
    
    print("\n🚀 YOUR PROJECT IS COMPLETE!")
    print("=" * 35)
    print("✅ Real-time cloud data updates")
    print("✅ Interactive graphs and patterns")
    print("✅ Smart threshold-based alerts")
    print("✅ Email notifications")
    print("✅ Professional Web UI")
    print("✅ Historical data tracking")
    print("✅ Mobile-responsive design")
    
    print("\n📱 ACCESS YOUR SYSTEM:")
    print("   Web UI: http://localhost:5001")
    print("   Data Source: HiveMQ Cloud")
    print("   Update Frequency: Every second")
    print("   Alert System: Active")

if __name__ == "__main__":
    main()
