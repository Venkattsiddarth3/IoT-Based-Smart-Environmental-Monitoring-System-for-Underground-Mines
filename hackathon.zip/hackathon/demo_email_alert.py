#!/usr/bin/env python3
"""
Demo script to show email alert functionality
Temperature threshold set to 25°C for demonstration
"""

import requests
import json
import time

def demo_email_alert():
    """Demonstrate email alert system"""
    print("🚨 EMAIL ALERT DEMONSTRATION")
    print("=" * 50)
    print("🌡️  Temperature Threshold: 25.0°C (DEMO SETTING)")
    print("📧 Email alerts will be sent when temperature > 25°C")
    print()
    
    # Get current data
    try:
        response = requests.get('http://localhost:5001/api/current_data')
        if response.status_code == 200:
            current_data = response.json()
            
            print("📊 CURRENT SENSOR READINGS:")
            print("-" * 30)
            for sensor, value in current_data.items():
                if sensor in ['temperature', 'mq2_gas', 'mq9_gas', 'humidity', 'noise']:
                    print(f"   {sensor}: {value}")
            
            print()
            print("🚨 THRESHOLD STATUS:")
            print("-" * 20)
            
            # Check temperature specifically
            current_temp = current_data.get('temperature', 0)
            temp_threshold = 25.0
            
            if current_temp > temp_threshold:
                print(f"   🌡️  Temperature: {current_temp}°C > {temp_threshold}°C")
                print("   🚨 THRESHOLD EXCEEDED!")
                print("   📧 EMAIL ALERT SHOULD BE SENT!")
                print()
                print("✅ DEMO SUCCESSFUL!")
                print("📧 Check your email for the alert notification")
                print("🌐 Also check the web UI at: http://localhost:5001")
                print("   - Latest Reading box will show the alert")
                print("   - Alert banner will appear on the web page")
            else:
                print(f"   🌡️  Temperature: {current_temp}°C <= {temp_threshold}°C")
                print("   ✅ Within safe limits")
                print("   📧 No email alert needed")
            
            return True
            
        else:
            print(f"❌ Error getting current data: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def show_thresholds():
    """Show current thresholds"""
    print("\n📋 CURRENT THRESHOLDS:")
    print("-" * 25)
    thresholds = {
        'mq2_gas': 50.0,
        'mq9_gas': 30.0,
        'temperature': 25.0,  # DEMO: Set to 25°C
        'humidity': 90.0,
        'noise': 50.0
    }
    
    for sensor, threshold in thresholds.items():
        if sensor == 'temperature':
            print(f"   {sensor}: {threshold} (🚨 DEMO SETTING)")
        else:
            print(f"   {sensor}: {threshold}")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 EMAIL ALERT DEMONSTRATION")
    print("=" * 60)
    print()
    
    # Wait for system to start
    print("⏳ Waiting for system to start...")
    time.sleep(5)
    
    # Show thresholds
    show_thresholds()
    
    # Demo email alert
    success = demo_email_alert()
    
    print("\n" + "=" * 60)
    if success:
        print("🎉 DEMO COMPLETED SUCCESSFULLY!")
        print("📧 Email alert system is working!")
        print("🌐 Access your system: http://localhost:5001")
    else:
        print("⚠️  Demo failed. Check system status.")

if __name__ == "__main__":
    main()
