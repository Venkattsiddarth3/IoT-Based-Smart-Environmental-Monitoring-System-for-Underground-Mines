#!/usr/bin/env python3
"""
Test Email Alert System for Underground Mining Monitor
"""

import os
from dotenv import load_dotenv
from email_alerts import EmailAlertSystem

def test_email_configuration():
    """Test email configuration"""
    print("📧 TESTING EMAIL ALERT SYSTEM")
    print("=" * 50)
    
    # Load environment variables
    load_dotenv()
    
    # Check configuration
    email_user = os.getenv('EMAIL_USER', '')
    email_password = os.getenv('EMAIL_PASSWORD', '')
    recipient_emails = os.getenv('RECIPIENT_EMAILS', '')
    
    print("📋 Email Configuration:")
    print(f"   SMTP Server: {os.getenv('EMAIL_SMTP_SERVER', 'smtp.gmail.com')}")
    print(f"   SMTP Port: {os.getenv('EMAIL_SMTP_PORT', '587')}")
    print(f"   Email User: {email_user}")
    print(f"   Email Password: {'*' * len(email_password) if email_password else 'Not set'}")
    print(f"   Recipients: {recipient_emails}")
    
    if not email_user or not email_password:
        print("❌ Email credentials not configured properly")
        return False
    
    if not recipient_emails:
        print("❌ Recipient emails not configured")
        return False
    
    print("✅ Email configuration looks good!")
    return True

def test_email_alert():
    """Test sending an email alert"""
    print("\n🚨 TESTING EMAIL ALERT")
    print("=" * 50)
    
    # Create test alert data
    test_alerts = [
        {
            'sensor': 'mq2_gas',
            'value': 450,
            'threshold': 300,
            'timestamp': '2025-09-25T04:40:00'
        },
        {
            'sensor': 'mq9_gas',
            'value': 250,
            'threshold': 200,
            'timestamp': '2025-09-25T04:40:00'
        }
    ]
    
    print("📊 Test Alert Data:")
    for alert in test_alerts:
        print(f"   {alert['sensor']}: {alert['value']} (Threshold: {alert['threshold']})")
    
    # Initialize email system
    email_system = EmailAlertSystem()
    
    print("\n📧 Sending test email alert...")
    try:
        success = email_system.send_alert(test_alerts)
        if success:
            print("✅ Email alert sent successfully!")
            print("📬 Check the recipient email inboxes for the alert")
        else:
            print("❌ Failed to send email alert")
    except Exception as e:
        print(f"❌ Error sending email: {e}")

def show_email_features():
    """Show email alert features"""
    print("\n📧 EMAIL ALERT FEATURES")
    print("=" * 50)
    
    features = [
        "📧 Professional HTML-formatted emails",
        "🚨 Clear danger alerts with sensor details",
        "📊 Current values vs safety thresholds",
        "⚠️ Emergency action recommendations",
        "🕐 Timestamp of alert occurrence",
        "📱 Mobile-friendly email format",
        "🎨 Color-coded alert levels",
        "📋 Multiple recipient support"
    ]
    
    for feature in features:
        print(f"   {feature}")
    
    print("\n📬 Email Recipients:")
    recipients = os.getenv('RECIPIENT_EMAILS', '').split(',')
    for i, recipient in enumerate(recipients, 1):
        print(f"   {i}. {recipient.strip()}")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 EMAIL ALERT SYSTEM TEST")
    print("=" * 60)
    
    # Test configuration
    config_ok = test_email_configuration()
    
    if config_ok:
        # Show features
        show_email_features()
        
        # Ask user if they want to send test email
        print("\n" + "=" * 60)
        print("🧪 Would you like to send a test email alert?")
        print("   This will send a test alert to all configured recipients")
        
        try:
            response = input("   Send test email? (y/n): ").lower().strip()
            if response in ['y', 'yes']:
                test_email_alert()
            else:
                print("   Skipping test email send")
        except KeyboardInterrupt:
            print("\n   Test cancelled")
    else:
        print("\n❌ Please configure email settings in .env file")
        print("   Copy env_example.txt to .env and fill in your credentials")
    
    print("\n" + "=" * 60)
    print("✅ Email alert system test completed!")

if __name__ == "__main__":
    main()
