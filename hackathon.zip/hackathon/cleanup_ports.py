#!/usr/bin/env python3
"""
Port cleanup script for the monitoring system
"""

import subprocess
import sys

def kill_process_on_port(port):
    """Kill any process running on the specified port"""
    try:
        # Find process ID using the port
        result = subprocess.run(['lsof', '-ti', f':{port}'], 
                              capture_output=True, text=True)
        
        if result.returncode == 0 and result.stdout.strip():
            pids = result.stdout.strip().split('\n')
            for pid in pids:
                if pid:
                    print(f"🔪 Killing process {pid} on port {port}")
                    subprocess.run(['kill', '-9', pid])
            return True
        else:
            print(f"✅ Port {port} is free")
            return False
    except Exception as e:
        print(f"❌ Error checking port {port}: {e}")
        return False

def main():
    print("🧹 Port Cleanup for Underground Mining Monitor")
    print("=" * 50)
    
    # Common ports used by the application
    ports_to_check = [5000, 5001, 5002, 5003, 5004]
    
    for port in ports_to_check:
        kill_process_on_port(port)
    
    print("\n✅ Port cleanup completed!")
    print("You can now run: python3 run.py")

if __name__ == "__main__":
    main()
