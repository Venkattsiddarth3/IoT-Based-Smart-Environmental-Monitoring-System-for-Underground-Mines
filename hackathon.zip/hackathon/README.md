# Underground Mining Environmental Monitoring System

A comprehensive real-time environmental monitoring system for underground coal mining operations. This system monitors various environmental parameters through ESP32 sensors and provides real-time visualization, alerting, and historical data tracking.

## Features

### 🔍 Real-time Monitoring
- **MQ2 Gas Sensor**: Monitors Methane, LPG, Propane levels
- **MQ9 Gas Sensor**: Tracks CO, LPG, CH4 concentrations
- **Heart Rate Sensor**: Monitors worker health
- **DHT11 Temperature Sensor**: Environmental temperature monitoring
- **DHT11 Humidity Sensor**: Air humidity levels
- **Noise Sensor**: Sound level monitoring

### 📊 Data Visualization
- Real-time sensor value displays with trend indicators
- Interactive charts showing data trends over time
- Color-coded status indicators (Safe/Warning/Danger)
- Historical data table with timestamps

### 🚨 Alert System
- **Threshold Monitoring**: Configurable danger levels for each sensor
- **Email Alerts**: HTML-formatted email notifications
- **Telegram Alerts**: Instant messaging notifications
- **Visual Alerts**: Web-based alert banners
- **Audio/Visual Indicators**: Card animations for danger states

### 📈 Advanced Features
- **Trend Analysis**: Arrow indicators showing increasing/decreasing trends
- **Data Storage**: SQLite database for historical data
- **Real-time Updates**: WebSocket-based live data streaming
- **Responsive Design**: Mobile-friendly interface
- **Connection Status**: Live connection monitoring

## System Architecture

```
ESP32 Sensors → HiveMQ Cloud → Python Backend → Web Interface
                     ↓
              Database Storage
                     ↓
              Alert System (Email/Telegram)
```

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager
- Internet connection for MQTT and alert services

### Setup Instructions

1. **Clone or Download the Project**
   ```bash
   cd /path/to/your/project
   ```

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure Environment Variables**
   - Copy `env_example.txt` to `.env`
   - Fill in your email and Telegram credentials:
   ```bash
   cp env_example.txt .env
   ```

4. **Email Configuration (Optional)**
   - For Gmail: Use App Password instead of regular password
   - Enable 2-factor authentication and generate App Password
   - Add recipient email addresses (comma-separated)

5. **Telegram Configuration (Optional)**
   - Create a Telegram bot via @BotFather
   - Get your chat ID using @userinfobot
   - Add bot token and chat ID to `.env`

6. **Run the Application**
   ```bash
   python app.py
   ```

7. **Access the Web Interface**
   - Open browser and go to: `http://localhost:5000`
   - The system will automatically connect to HiveMQ cloud

## Configuration

### Sensor Thresholds
Default danger thresholds are set in `app.py`:
```python
THRESHOLDS = {
    'mq2_gas': 300,      # ppm - Methane, LPG, Propane
    'mq9_gas': 200,      # ppm - CO, LPG, CH4
    'heart_rate': 100,   # bpm - High heart rate
    'temperature': 35,   # °C - High temperature
    'humidity': 80,      # % - High humidity
    'noise': 85          # dB - High noise level
}
```

### MQTT Configuration
The system is pre-configured to connect to your HiveMQ cloud:
- Server: `c2d3d6cc30c0464cbfb2273abea14ca6.s1.eu.hivemq.cloud`
- Port: `8883` (Secure TLS)
- Username: `Rahul_Tej123`
- Topic: `sensor/data`

## ESP32 Arduino Code Integration

Your ESP32 should publish sensor data in the following JSON format to the `sensor/data` topic:

```json
{
    "mq2_gas": 150.5,
    "mq9_gas": 120.3,
    "heart_rate": 75.0,
    "temperature": 28.5,
    "humidity": 65.2,
    "noise": 45.8
}
```

## Usage

### Web Interface
1. **Dashboard**: View all sensor readings in real-time
2. **Charts**: Monitor trends and patterns over time
3. **Alerts**: See active alerts and threshold breaches
4. **History**: Browse historical data in table format

### Alert Management
- **Automatic Alerts**: Sent when any sensor exceeds threshold
- **Email Alerts**: Professional HTML-formatted notifications
- **Telegram Alerts**: Instant mobile notifications
- **Visual Alerts**: Web-based alert banners with auto-dismiss

### Data Analysis
- **Trend Indicators**: Arrows showing increasing/decreasing patterns
- **Color Coding**: Green (Safe), Yellow (Warning), Red (Danger)
- **Progress Bars**: Visual representation of threshold proximity
- **Historical Tracking**: Complete data history with timestamps

## Safety Features

### Emergency Protocols
- **Gas Leak Detection**: Immediate alerts for dangerous gas levels
- **Health Monitoring**: Worker heart rate and environmental stress
- **Environmental Hazards**: Temperature, humidity, and noise monitoring
- **Evacuation Alerts**: Clear danger indicators for emergency response

### Data Integrity
- **Real-time Validation**: Continuous data quality checks
- **Connection Monitoring**: Automatic reconnection to MQTT broker
- **Data Persistence**: All readings stored in local database
- **Backup Systems**: Multiple alert channels for redundancy

## Troubleshooting

### Common Issues

1. **MQTT Connection Failed**
   - Check internet connection
   - Verify HiveMQ credentials
   - Ensure ESP32 is publishing to correct topic

2. **Email Alerts Not Working**
   - Verify email credentials in `.env`
   - Check SMTP server settings
   - Ensure App Password is used for Gmail

3. **Telegram Alerts Not Working**
   - Verify bot token and chat ID
   - Ensure bot is added to chat
   - Check internet connectivity

4. **No Data Displayed**
   - Check ESP32 sensor connections
   - Verify MQTT topic name
   - Check JSON data format

### Logs and Debugging
- Check console output for connection status
- Monitor browser developer tools for WebSocket connections
- Verify database file creation (`sensor_data.db`)

## File Structure

```
hackathon/
├── app.py                 # Main Flask application
├── email_alerts.py        # Email alert system
├── requirements.txt       # Python dependencies
├── env_example.txt        # Environment variables template
├── README.md             # This file
├── templates/
│   └── index.html        # Web interface template
├── static/
│   ├── css/
│   │   └── style.css     # Custom styling
│   └── js/
│       └── app.js        # Frontend JavaScript
└── sensor_data.db        # SQLite database (created automatically)
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is developed for educational and safety purposes in mining operations.

## Support

For technical support or questions:
- Check the troubleshooting section
- Review console logs for error messages
- Ensure all dependencies are properly installed
- Verify network connectivity and credentials

## Safety Disclaimer

This system is designed to assist in environmental monitoring but should not be the sole safety mechanism. Always follow proper mining safety protocols and have backup monitoring systems in place.

