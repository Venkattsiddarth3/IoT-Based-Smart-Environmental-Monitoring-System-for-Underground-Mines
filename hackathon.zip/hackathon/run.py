#!/usr/bin/env python3
"""
Underground Mining Environmental Monitoring System
Launch script for the monitoring application
"""

import os
import sys
import subprocess
from pathlib import Path

def check_dependencies():
    """Check if all required dependencies are installed"""
    try:
        import flask
        import flask_socketio
        import paho.mqtt.client
        import requests
        import dotenv
        print("✅ All dependencies are installed")
        return True
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("Please run: pip install -r requirements.txt")
        return False

def check_env_file():
    """Check if environment file exists"""
    env_file = Path(".env")
    if not env_file.exists():
        print("⚠️  .env file not found")
        print("Please copy env_example.txt to .env and configure your settings")
        return False
    print("✅ Environment file found")
    return True

def create_directories():
    """Create necessary directories if they don't exist"""
    directories = ['templates', 'static/css', 'static/js']
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
    print("✅ Directory structure verified")

def main():
    """Main launch function"""
    print("🚀 Starting Underground Mining Environmental Monitoring System")
    print("=" * 60)
    
    # Check system requirements
    if not check_dependencies():
        sys.exit(1)
    
    create_directories()
    
    # Check environment file (optional)
    env_exists = check_env_file()
    if not env_exists:
        print("⚠️  Running without email/Telegram alerts")
        print("   To enable alerts, configure .env file")
    
    print("\n🌐 Starting web server...")
    print("📊 Dashboard will be available at: http://localhost:5000")
    print("📡 Connecting to HiveMQ Cloud...")
    print("🔔 Alert system status:", "Enabled" if env_exists else "Disabled")
    print("\n" + "=" * 60)
    
    # Launch the application
    try:
        from app import app, socketio, init_database, mqtt_client
        
        # Initialize database and MQTT
        init_database()
        mqtt_client.connect()
        
        # Try different ports if 5000 is busy
        ports_to_try = [5000, 5001, 5002, 5003, 5004]
        
        for port in ports_to_try:
            try:
                print(f"🌐 Starting web server on port {port}...")
                socketio.run(app, debug=False, host='0.0.0.0', port=port)
                break
            except OSError as e:
                if "Address already in use" in str(e):
                    print(f"❌ Port {port} is busy, trying next port...")
                    continue
                else:
                    print(f"❌ Error: {e}")
                    break
        else:
            print("❌ All ports are busy. Please free up a port or restart your system.")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\n🛑 Shutting down monitoring system...")
        print("✅ System stopped safely")
    except Exception as e:
        print(f"\n❌ Error starting system: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

