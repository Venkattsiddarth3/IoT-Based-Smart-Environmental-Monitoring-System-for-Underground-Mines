#!/usr/bin/env python3
"""
Test script to verify chart functionality and data flow
"""

import requests
import json
import time

def test_chart_data_flow():
    """Test that data is flowing properly for charts"""
    print("📊 TESTING CHART FUNCTIONALITY")
    print("=" * 50)
    
    try:
        # Test current data API
        print("🔍 Testing current data API...")
        response = requests.get('http://localhost:5001/api/current_data')
        if response.status_code == 200:
            current_data = response.json()
            print("✅ Current data API working!")
            print("📊 Current sensor readings:")
            for sensor, value in current_data.items():
                print(f"   {sensor}: {value}")
        else:
            print(f"❌ Current data API error: {response.status_code}")
            return False

        # Test historical data API
        print("\n🔍 Testing historical data API...")
        response = requests.get('http://localhost:5001/api/historical_data')
        if response.status_code == 200:
            historical_data = response.json()
            print(f"✅ Historical data API working! ({len(historical_data)} records)")
            
            if len(historical_data) > 0:
                print("📊 Latest historical record:")
                latest = historical_data[-1]
                for key, value in latest.items():
                    print(f"   {key}: {value}")
            else:
                print("⚠️  No historical data found")
        else:
            print(f"❌ Historical data API error: {response.status_code}")
            return False

        # Test thresholds API
        print("\n🔍 Testing thresholds API...")
        response = requests.get('http://localhost:5001/api/thresholds')
        if response.status_code == 200:
            thresholds = response.json()
            print("✅ Thresholds API working!")
            print("📊 Current thresholds:")
            for sensor, threshold in thresholds.items():
                print(f"   {sensor}: {threshold}")
        else:
            print(f"❌ Thresholds API error: {response.status_code}")
            return False

        return True
        
    except Exception as e:
        print(f"❌ Error testing APIs: {e}")
        return False

def test_web_ui_access():
    """Test that the web UI is accessible"""
    print("\n🌐 TESTING WEB UI ACCESS")
    print("=" * 30)
    
    try:
        response = requests.get('http://localhost:5001/')
        if response.status_code == 200:
            print("✅ Web UI is accessible!")
            print("📱 Open your browser and go to: http://localhost:5001")
            return True
        else:
            print(f"❌ Web UI error: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error accessing Web UI: {e}")
        return False

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📊 CHART FUNCTIONALITY TEST")
    print("=" * 60)
    
    # Wait for system to start
    print("⏳ Waiting for system to start...")
    time.sleep(3)
    
    # Test APIs
    api_success = test_chart_data_flow()
    
    # Test Web UI
    ui_success = test_web_ui_access()
    
    print("\n📋 TEST RESULTS:")
    print("=" * 20)
    print(f"✅ API Tests: {'PASSED' if api_success else 'FAILED'}")
    print(f"✅ Web UI Tests: {'PASSED' if ui_success else 'FAILED'}")
    
    if api_success and ui_success:
        print("\n🎉 ALL TESTS PASSED!")
        print("📊 Chart.js should now be working with live data!")
        print("\n🌐 Access your system:")
        print("   URL: http://localhost:5001")
        print("   Features: Live charts, Real-time data, Latest reading box")
    else:
        print("\n⚠️  Some tests failed. Check the system status.")

if __name__ == "__main__":
    main()
