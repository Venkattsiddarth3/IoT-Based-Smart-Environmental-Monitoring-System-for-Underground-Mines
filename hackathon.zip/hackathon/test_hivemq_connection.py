#!/usr/bin/env python3
"""
Test HiveMQ Cloud connection specifically
"""

import paho.mqtt.client as mqtt
import json
import time

# MQTT Configuration (same as in app.py)
MQTT_SERVER = "c2d3d6cc30c0464cbfb2273abea14ca6.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USER = "Rahul_Tej123"
MQTT_PASSWORD = "SMDRizwan9"
MQTT_TOPIC = "sensor/data"

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("✅ Successfully connected to HiveMQ Cloud!")
        print(f"📡 Subscribing to topic: {MQTT_TOPIC}")
        client.subscribe(MQTT_TOPIC)
    else:
        print(f"❌ Failed to connect to HiveMQ Cloud. Return code: {rc}")
        print("Possible issues:")
        print("- Check internet connection")
        print("- Verify HiveMQ credentials")
        print("- Check if ESP32 is sending data")

def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode())
        print(f"📊 Received sensor data:")
        print(f"   MQ2 Gas: {data.get('mq2_gas', 'N/A')} ppm")
        print(f"   MQ9 Gas: {data.get('mq9_gas', 'N/A')} ppm")
        print(f"   Heart Rate: {data.get('heart_rate', 'N/A')} bpm")
        print(f"   Temperature: {data.get('temperature', 'N/A')} °C")
        print(f"   Humidity: {data.get('humidity', 'N/A')} %")
        print(f"   Noise: {data.get('noise', 'N/A')} dB")
        print("-" * 40)
    except Exception as e:
        print(f"❌ Error parsing message: {e}")

def on_disconnect(client, userdata, rc):
    print("🔌 Disconnected from HiveMQ Cloud")

def test_hivemq_connection():
    print("🔍 Testing HiveMQ Cloud Connection")
    print("=" * 50)
    print(f"Server: {MQTT_SERVER}")
    print(f"Port: {MQTT_PORT}")
    print(f"Username: {MQTT_USER}")
    print(f"Topic: {MQTT_TOPIC}")
    print("=" * 50)
    
    # Create MQTT client
    client = mqtt.Client()
    client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
    client.tls_set()
    
    # Set callbacks
    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect
    
    try:
        print("🔗 Connecting to HiveMQ Cloud...")
        client.connect(MQTT_SERVER, MQTT_PORT, 60)
        client.loop_start()
        
        print("⏳ Waiting for data from ESP32...")
        print("   (Make sure ESP32 is running and sending data)")
        print("   Press Ctrl+C to stop")
        
        # Wait for messages
        time.sleep(30)  # Wait 30 seconds for data
        
    except KeyboardInterrupt:
        print("\n🛑 Stopping test...")
    except Exception as e:
        print(f"❌ Connection error: {e}")
    finally:
        client.loop_stop()
        client.disconnect()
        print("✅ Test completed")

if __name__ == "__main__":
    test_hivemq_connection()
