#!/usr/bin/env python3
"""
Fix email setup for Gmail - Step by step guide
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def test_email_credentials():
    """Test current email credentials"""
    print("📧 TESTING EMAIL CREDENTIALS")
    print("=" * 40)
    
    # Current credentials from env_example.txt
    email_user = "rangajal@gitam.in"
    email_password = "7036229529dad."
    recipient_emails = ["sgnana@gitam.in", "vnuggu@gitam.in"]
    
    print(f"📤 From: {email_user}")
    print(f"📥 To: {', '.join(recipient_emails)}")
    print(f"🔑 Password: {email_password}")
    print()
    
    try:
        # Create message
        msg = MIMEMultipart()
        msg['From'] = email_user
        msg['To'] = ', '.join(recipient_emails)
        msg['Subject'] = "🧪 TEST EMAIL - Underground Mining Monitor"
        
        body = """
        <html>
        <body>
        <h2>🧪 Test Email from Underground Mining Monitor</h2>
        <p>This is a test email to verify the email alert system is working.</p>
        <p><strong>System Status:</strong> ✅ Email system is functional</p>
        <p><strong>Time:</strong> """ + str(__import__('datetime').datetime.now()) + """</p>
        <hr>
        <p><em>This email was sent automatically by the Underground Mining Environmental Monitoring System.</em></p>
        </body>
        </html>
        """
        
        msg.attach(MIMEText(body, 'html'))
        
        # Create secure connection
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        
        print("🔗 Connecting to Gmail SMTP...")
        with smtplib.SMTP('smtp.gmail.com', 587, timeout=30) as server:
            print("🔒 Starting TLS...")
            server.starttls(context=context)
            
            print("🔑 Logging in...")
            server.login(email_user, email_password)
            
            print("📧 Sending email...")
            server.send_message(msg)
            
        print("✅ Email sent successfully!")
        print("📥 Check the recipient email inboxes for the test email")
        return True
        
    except smtplib.SMTPAuthenticationError as e:
        print("❌ Authentication Error:")
        print("   Gmail is rejecting the username/password")
        print("   This usually means you need to:")
        print("   1. Enable 2-Factor Authentication on Gmail")
        print("   2. Generate an 'App Password'")
        print("   3. Use the App Password instead of your regular password")
        print()
        print("🔧 SOLUTION:")
        print("   1. Go to Gmail → Settings → Security")
        print("   2. Enable 2-Factor Authentication")
        print("   3. Generate App Password for 'Mail'")
        print("   4. Use the 16-character App Password")
        return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def show_gmail_setup_guide():
    """Show detailed Gmail setup guide"""
    print("\n📋 GMAIL APP PASSWORD SETUP GUIDE")
    print("=" * 50)
    print("1. 🔐 Go to your Gmail account")
    print("2. ⚙️  Click Settings → Security")
    print("3. 🔒 Enable 2-Factor Authentication")
    print("4. 🔑 Go to 'App passwords' section")
    print("5. 📱 Select 'Mail' as the app")
    print("6. 📋 Copy the 16-character password")
    print("7. 🔄 Update the EMAIL_PASSWORD in your .env file")
    print()
    print("📝 Example App Password: 'abcd efgh ijkl mnop'")
    print("   (Remove spaces: 'abcdefghijklmnop')")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 EMAIL SETUP FIX")
    print("=" * 50)
    
    # Test current credentials
    success = test_email_credentials()
    
    if not success:
        show_gmail_setup_guide()
        print("\n🔧 NEXT STEPS:")
        print("1. Follow the Gmail setup guide above")
        print("2. Update your .env file with the App Password")
        print("3. Run this script again to test")
        print("4. Once working, restart the main system")
    else:
        print("\n🎉 EMAIL SYSTEM IS WORKING!")
        print("📧 Test emails have been sent")
        print("🌐 Your alert system is ready")

if __name__ == "__main__":
    main()
