#!/usr/bin/env python3
"""
Simple email test - Run this to test email functionality
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

def send_test_email():
    """Send a simple test email"""
    print("📧 SENDING TEST EMAIL")
    print("=" * 30)
    
    # Email configuration
    email_user = "rangajal@gitam.in"
    email_password = "7036229529dad."  # You need to update this with App Password
    recipient_emails = ["sgnana@gitam.in", "vnuggu@gitam.in"]
    
    print(f"📤 From: {email_user}")
    print(f"📥 To: {', '.join(recipient_emails)}")
    print()
    
    try:
        # Create message
        msg = MIMEMultipart()
        msg['From'] = email_user
        msg['To'] = ', '.join(recipient_emails)
        msg['Subject'] = "🚨 TEST ALERT - Underground Mining Monitor"
        
        # Create email body
        body = f"""
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px;">
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 10px;">
            <h2 style="color: #dc3545;">🚨 DANGER ALERT - Underground Mining Environment</h2>
            
            <div style="background-color: white; padding: 15px; border-radius: 5px; margin: 10px 0;">
                <h3 style="color: #dc3545;">⚠️ Threshold Exceeded</h3>
                <p><strong>Sensor:</strong> Temperature</p>
                <p><strong>Current Value:</strong> 27.5°C</p>
                <p><strong>Threshold:</strong> 26.0°C</p>
                <p><strong>Status:</strong> <span style="color: #dc3545;">DANGER - THRESHOLD EXCEEDED</span></p>
            </div>
            
            <div style="background-color: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;">
                <h4>📋 Action Required:</h4>
                <ul>
                    <li>Immediately check the mining environment</li>
                    <li>Verify temperature sensors</li>
                    <li>Ensure proper ventilation</li>
                    <li>Monitor for any safety hazards</li>
                </ul>
            </div>
            
            <div style="background-color: #d1ecf1; padding: 15px; border-radius: 5px; margin: 10px 0;">
                <p><strong>Alert Time:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
                <p><strong>System:</strong> Underground Mining Environmental Monitor</p>
                <p><strong>Location:</strong> Coal Mining Site</p>
            </div>
            
            <hr style="margin: 20px 0;">
            <p style="color: #6c757d; font-size: 12px;">
                This is an automated alert from the Underground Mining Environmental Monitoring System.<br>
                Please take immediate action if this is a real emergency.
            </p>
        </div>
        </body>
        </html>
        """
        
        msg.attach(MIMEText(body, 'html'))
        
        # Create secure connection
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        
        print("🔗 Connecting to Gmail...")
        with smtplib.SMTP('smtp.gmail.com', 587, timeout=30) as server:
            print("🔒 Starting TLS...")
            server.starttls(context=context)
            
            print("🔑 Logging in...")
            server.login(email_user, email_password)
            
            print("📧 Sending email...")
            server.send_message(msg)
            
        print("✅ Email sent successfully!")
        print("📥 Check the recipient email inboxes:")
        for email in recipient_emails:
            print(f"   - {email}")
        
        return True
        
    except smtplib.SMTPAuthenticationError as e:
        print("❌ Authentication Error!")
        print("🔧 SOLUTION:")
        print("1. Go to Gmail → Settings → Security")
        print("2. Enable 2-Factor Authentication")
        print("3. Generate App Password for 'Mail'")
        print("4. Update the email_password in this script")
        print()
        print("📝 The App Password should be 16 characters like: 'abcdefghijklmnop'")
        return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 EMAIL TEST")
    print("=" * 40)
    print()
    
    success = send_test_email()
    
    if success:
        print("\n🎉 EMAIL SYSTEM IS WORKING!")
        print("📧 Test alert email has been sent")
        print("🌐 Your mining monitor alert system is ready")
    else:
        print("\n⚠️  Email setup needed:")
        print("1. Follow the Gmail App Password setup")
        print("2. Update the email_password in this script")
        print("3. Run this script again")

if __name__ == "__main__":
    main()
