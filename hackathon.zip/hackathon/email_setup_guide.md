# Email Alert Setup Guide

## Current Configuration

Your email alerts are configured with:
- **SMTP Server**: smtp.gmail.com
- **Port**: 587 (TLS)
- **From**: rangajal@gitam.in
- **Recipients**: sgnana@gitam.in, vnuggu@gitam.in

## Email Alert Features

✅ **Professional HTML-formatted emails**
✅ **Clear danger alerts with sensor details**
✅ **Current values vs safety thresholds**
✅ **Emergency action recommendations**
✅ **Timestamp of alert occurrence**
✅ **Mobile-friendly email format**
✅ **Color-coded alert levels**
✅ **Multiple recipient support**

## Troubleshooting Email Issues

### Issue: "Connection unexpectedly closed"

This is usually due to Gmail's security settings. Here are solutions:

### Solution 1: Enable App Passwords (Recommended)

1. **Enable 2-Factor Authentication** on your Gmail account
2. **Generate App Password**:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate password for "Mail"
   - Use this password in your .env file

### Solution 2: Update .env File

```bash
# Update your .env file with app password
EMAIL_USER=rangajal@gitam.in
EMAIL_PASSWORD=your-16-character-app-password
```

### Solution 3: Alternative Email Providers

If Gmail doesn't work, try these alternatives:

#### Outlook/Hotmail:
```
EMAIL_SMTP_SERVER=smtp-mail.outlook.com
EMAIL_SMTP_PORT=587
```

#### Yahoo:
```
EMAIL_SMTP_SERVER=smtp.mail.yahoo.com
EMAIL_SMTP_PORT=587
```

## Testing Email Alerts

### Test 1: Simple Test
```bash
python3 simple_email_test.py
```

### Test 2: Full System Test
```bash
python3 test_email_alerts.py
```

### Test 3: Live System Test
1. Run the monitoring system
2. Wait for sensor data to exceed thresholds
3. Check email inboxes for alerts

## Email Alert Content

When alerts are triggered, recipients will receive:

### Subject Line:
🚨 DANGER ALERT - Underground Mining Environment

### Email Content:
- **Professional HTML formatting**
- **Sensor details with current values**
- **Safety thresholds**
- **Excess amounts over thresholds**
- **Emergency action recommendations**
- **Timestamp of alert**
- **System branding**

## Current Status

✅ **Email system is configured**
✅ **Recipients are set**
✅ **Alert content is ready**
⚠️ **Authentication may need app password**

## Next Steps

1. **Enable 2FA** on rangajal@gitam.in
2. **Generate app password**
3. **Update .env file**
4. **Test email sending**
5. **Monitor for real alerts**

## Alternative: Use Telegram Only

If email continues to have issues, the system will still send:
- ✅ **Telegram alerts** (working)
- ✅ **Web UI alerts** (working)
- ✅ **Visual indicators** (working)

The Telegram alerts provide instant notifications and are fully functional.
