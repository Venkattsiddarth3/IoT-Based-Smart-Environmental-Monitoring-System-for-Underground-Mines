#!/usr/bin/env python3
"""
Send a test email alert to verify the system is working
"""

import os
from dotenv import load_dotenv
from email_alerts import EmailAlertSystem

def send_test_email():
    """Send a test email alert"""
    print("📧 SENDING TEST EMAIL ALERT")
    print("=" * 50)
    
    # Load environment variables
    load_dotenv()
    
    # Create test alert data (simulating dangerous readings)
    test_alerts = [
        {
            'sensor': 'mq2_gas',
            'value': 450,
            'threshold': 300,
            'timestamp': '2025-09-25T04:45:00'
        },
        {
            'sensor': 'mq9_gas',
            'value': 250,
            'threshold': 200,
            'timestamp': '2025-09-25T04:45:00'
        },
        {
            'sensor': 'temperature',
            'value': 38,
            'threshold': 35,
            'timestamp': '2025-09-25T04:45:00'
        }
    ]
    
    print("📊 Test Alert Data:")
    for alert in test_alerts:
        print(f"   {alert['sensor']}: {alert['value']} (Threshold: {alert['threshold']})")
    
    # Initialize email system
    email_system = EmailAlertSystem()
    
    print("\n📧 Sending test email alert...")
    try:
        success = email_system.send_alert(test_alerts)
        if success:
            print("✅ Email alert sent successfully!")
            print("📬 Check the following email inboxes:")
            recipients = os.getenv('RECIPIENT_EMAILS', '').split(',')
            for recipient in recipients:
                print(f"   • {recipient.strip()}")
        else:
            print("❌ Failed to send email alert")
    except Exception as e:
        print(f"❌ Error sending email: {e}")

if __name__ == "__main__":
    send_test_email()
