#!/usr/bin/env python3
"""
Show email configuration and test threshold at 26°C
"""

import requests
import json
import time

def show_email_configuration():
    """Show which email addresses are configured"""
    print("📧 EMAIL CONFIGURATION")
    print("=" * 40)
    
    # Email configuration from env_example.txt
    email_config = {
        'SMTP_SERVER': 'smtp.gmail.com',
        'SMTP_PORT': 587,
        'FROM_EMAIL': 'rangajal@gitam.in',
        'RECIPIENT_EMAILS': ['sgnana@gitam.in', 'vnuggu@gitam.in']
    }
    
    print("📤 Sending From:")
    print(f"   Email: {email_config['FROM_EMAIL']}")
    print(f"   Server: {email_config['SMTP_SERVER']}:{email_config['SMTP_PORT']}")
    print()
    
    print("📥 Sending To:")
    for i, email in enumerate(email_config['RECIPIENT_EMAILS'], 1):
        print(f"   {i}. {email}")
    print()
    
    return email_config

def test_threshold_26():
    """Test with temperature threshold at 26°C"""
    print("🌡️  TEMPERATURE THRESHOLD TEST")
    print("=" * 35)
    print("🚨 New Threshold: 26.0°C")
    print()
    
    try:
        response = requests.get('http://localhost:5001/api/current_data')
        if response.status_code == 200:
            current_data = response.json()
            
            current_temp = current_data.get('temperature', 0)
            temp_threshold = 26.0
            
            print("📊 CURRENT STATUS:")
            print(f"   Temperature: {current_temp}°C")
            print(f"   Threshold: {temp_threshold}°C")
            print()
            
            if current_temp > temp_threshold:
                print("🚨 THRESHOLD EXCEEDED!")
                print("📧 EMAIL ALERT WILL BE SENT TO:")
                email_config = show_email_configuration()
                print("✅ Email alert system is active")
            else:
                print("✅ Within safe limits")
                print("📧 No email alert needed")
            
            return True
            
        else:
            print(f"❌ Error getting current data: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 EMAIL CONFIGURATION & THRESHOLD TEST")
    print("=" * 60)
    print()
    
    # Wait for system to start
    print("⏳ Waiting for system to start...")
    time.sleep(5)
    
    # Show email configuration
    show_email_configuration()
    
    # Test threshold
    success = test_threshold_26()
    
    print("\n" + "=" * 60)
    if success:
        print("🎉 SYSTEM READY!")
        print("📧 Email alerts configured and working")
        print("🌐 Access your system: http://localhost:5001")
    else:
        print("⚠️  System check failed. Check status.")

if __name__ == "__main__":
    main()
