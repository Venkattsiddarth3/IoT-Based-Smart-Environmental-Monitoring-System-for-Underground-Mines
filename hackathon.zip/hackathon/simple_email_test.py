#!/usr/bin/env python3
"""
Simple email test using basic SMTP
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from dotenv import load_dotenv

def send_simple_email():
    """Send a simple test email"""
    load_dotenv()
    
    # Email configuration
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    email_user = os.getenv('EMAIL_USER', '')
    email_password = os.getenv('EMAIL_PASSWORD', '')
    recipient_emails = os.getenv('RECIPIENT_EMAILS', '').split(',')
    
    print("📧 SIMPLE EMAIL TEST")
    print("=" * 40)
    print(f"From: {email_user}")
    print(f"To: {', '.join(recipient_emails)}")
    
    if not email_user or not email_password:
        print("❌ Email credentials not configured")
        return False
    
    try:
        # Create message
        msg = MIMEMultipart()
        msg['From'] = email_user
        msg['To'] = ', '.join(recipient_emails)
        msg['Subject'] = "🚨 TEST ALERT - Underground Mining Monitor"
        
        # Simple text body
        body = """
🚨 DANGER ALERT - Underground Mining Environment

⚠️ Critical Threshold Breaches Detected:

• MQ2 Gas: 450 ppm (Threshold: 300 ppm) - DANGER!
• MQ9 Gas: 250 ppm (Threshold: 200 ppm) - DANGER!
• Temperature: 38°C (Threshold: 35°C) - DANGER!

Immediate Action Required:
- Evacuate the area if gas levels are critical
- Check worker health and safety equipment
- Verify ventilation systems are functioning
- Contact emergency services if necessary

Alert Time: 2025-09-25 04:45:00

This is an automated alert from the Underground Mining Environmental Monitoring System.
        """
        
        msg.attach(MIMEText(body, 'plain'))
        
        # Send email
        print("Connecting to Gmail SMTP...")
        context = ssl.create_default_context()
        
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            print("Starting TLS...")
            server.starttls(context=context)
            print("Logging in...")
            server.login(email_user, email_password)
            print("Sending email...")
            server.send_message(msg)
        
        print("✅ Test email sent successfully!")
        print("📬 Check the recipient email inboxes")
        return True
        
    except Exception as e:
        print(f"❌ Error sending email: {e}")
        return False

if __name__ == "__main__":
    send_simple_email()
