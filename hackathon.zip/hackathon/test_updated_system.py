#!/usr/bin/env python3
"""
Test the updated system with only specified attributes
"""

import json
from datetime import datetime

def test_data_format():
    """Test the exact data format you specified"""
    print("🎯 TESTING UPDATED SYSTEM")
    print("=" * 50)
    
    # Your exact data format
    test_data = {
        "MQ2": 845,
        "MQ9": 809,
        "Noise": 95,
        "Humidity": 62.00,
        "Temperature": 28.20,
        "MQ2Alert": 0,
        "MQ9Alert": 0
    }
    
    print("📥 Your Exact Data Format:")
    print(json.dumps(test_data, indent=2))
    
    # Converted format for web UI
    converted_data = {
        'mq2_gas': test_data.get('MQ2', 0),
        'mq9_gas': test_data.get('MQ9', 0),
        'temperature': test_data.get('Temperature', 0),
        'humidity': test_data.get('Humidity', 0),
        'noise': test_data.get('Noise', 0),
        'mq2_alert': test_data.get('MQ2Alert', 0),
        'mq9_alert': test_data.get('MQ9Alert', 0)
    }
    
    print("\n📤 Converted for Web UI:")
    print(json.dumps(converted_data, indent=2))
    
    print("\n🌐 Web UI Display:")
    print(f"   MQ2 Gas: {converted_data['mq2_gas']} ppm")
    print(f"   MQ9 Gas: {converted_data['mq9_gas']} ppm")
    print(f"   Temperature: {converted_data['temperature']} °C")
    print(f"   Humidity: {converted_data['humidity']} %")
    print(f"   Noise: {converted_data['noise']} dB")
    print(f"   MQ2 Alert: {'ALERT' if converted_data['mq2_alert'] else 'CLEAR'}")
    print(f"   MQ9 Alert: {'ALERT' if converted_data['mq9_alert'] else 'CLEAR'}")
    
    print("\n✅ System updated successfully!")
    print("   • Removed Heart Rate sensor")
    print("   • Added MQ2/MQ9 Alert status")
    print("   • Updated charts and tables")
    print("   • Ready for your exact data format")

def show_web_ui_features():
    """Show what's displayed in the web UI"""
    print("\n🌐 WEB UI FEATURES")
    print("=" * 50)
    
    print("📊 Sensor Cards (5 total):")
    print("   1. MQ2 Gas Sensor - Methane, LPG, Propane")
    print("   2. MQ9 Gas Sensor - CO, LPG, CH4")
    print("   3. Temperature Sensor - DHT11")
    print("   4. Humidity Sensor - DHT11")
    print("   5. Noise Sensor - Sound Level")
    
    print("\n📈 Charts:")
    print("   • Real-time line chart with 5 data series")
    print("   • Trend indicators (arrows)")
    print("   • Color-coded lines for each sensor")
    
    print("\n📋 Historical Table:")
    print("   • Timestamp")
    print("   • MQ2 Gas (ppm)")
    print("   • MQ9 Gas (ppm)")
    print("   • Temperature (°C)")
    print("   • Humidity (%)")
    print("   • Noise (dB)")
    print("   • MQ2 Alert Status")
    print("   • MQ9 Alert Status")
    
    print("\n🚨 Alert Features:")
    print("   • Visual alert indicators on gas sensor cards")
    print("   • Email notifications for threshold breaches")
    print("   • Telegram alerts for instant notifications")
    print("   • Web alert banners for emergencies")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("🎯 UPDATED SYSTEM TEST")
    print("=" * 60)
    print(f"🕐 Test Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    test_data_format()
    show_web_ui_features()
    
    print("\n" + "=" * 60)
    print("🎉 SYSTEM READY!")
    print("📋 Your data format is perfectly configured")
    print("🚀 Run: python3 run.py")
    print("🌐 Open: http://localhost:5001")
    print("📊 Watch your real-time data!")

if __name__ == "__main__":
    main()
