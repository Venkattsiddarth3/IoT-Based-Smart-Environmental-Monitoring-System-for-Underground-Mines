import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

class EmailAlertSystem:
    def __init__(self):
        self.smtp_server = os.getenv('EMAIL_SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('EMAIL_SMTP_PORT', '587'))
        self.email_user = os.getenv('EMAIL_USER', '')
        self.email_password = os.getenv('EMAIL_PASSWORD', '')
        self.recipient_emails = os.getenv('RECIPIENT_EMAILS', '').split(',')
        
    def send_alert(self, alerts):
        """Send email alert for threshold breaches"""
        if not self.email_user or not self.email_password:
            print("Email credentials not configured")
            return False
            
        try:
            # Create message
            msg = MIMEMultipart()
            msg['From'] = self.email_user
            msg['To'] = ', '.join(self.recipient_emails)
            msg['Subject'] = "🚨 DANGER ALERT - Underground Mining Environment"
            
            # Create email body
            body = self.create_email_body(alerts)
            msg.attach(MIMEText(body, 'html'))
            
            # Create secure connection and send email
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            print(f"Connecting to {self.smtp_server}:{self.smtp_port}")
            with smtplib.SMTP(self.smtp_server, self.smtp_port, timeout=30) as server:
                print("Starting TLS...")
                server.starttls(context=context)
                print("Logging in...")
                server.login(self.email_user, self.email_password)
                print("Sending email...")
                server.send_message(msg)
                
            print("✅ Email alert sent successfully")
            return True
            
        except Exception as e:
            print(f"❌ Failed to send email alert: {e}")
            return False
    
    def create_email_body(self, alerts):
        """Create HTML email body for alerts"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #dc3545; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; }}
                .alert-item {{ background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 10px 0; border-radius: 5px; }}
                .sensor-name {{ font-weight: bold; color: #721c24; }}
                .value {{ color: #721c24; }}
                .threshold {{ color: #856404; }}
                .footer {{ background-color: #f8f9fa; padding: 15px; text-align: center; font-size: 12px; color: #6c757d; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🚨 DANGER ALERT</h1>
                <h2>Underground Mining Environment</h2>
            </div>
            
            <div class="content">
                <h3>⚠️ Critical Threshold Breaches Detected</h3>
                <p>The following sensors have exceeded their safety thresholds:</p>
                
                {self.create_alert_items(alerts)}
                
                <h3>Immediate Action Required:</h3>
                <ul>
                    <li>Evacuate the area if gas levels are critical</li>
                    <li>Check worker health and safety equipment</li>
                    <li>Verify ventilation systems are functioning</li>
                    <li>Contact emergency services if necessary</li>
                </ul>
                
                <p><strong>Alert Time:</strong> {timestamp}</p>
            </div>
            
            <div class="footer">
                <p>This is an automated alert from the Underground Mining Environmental Monitoring System</p>
                <p>Please do not reply to this email</p>
            </div>
        </body>
        </html>
        """
        
        return html_body
    
    def create_alert_items(self, alerts):
        """Create HTML for individual alert items"""
        items_html = ""
        
        for alert in alerts:
            sensor_name = alert['sensor'].replace('_', ' ').title()
            if sensor_name == 'Mq2 Gas':
                sensor_name = 'MQ2 Gas (Methane, LPG, Propane)'
            elif sensor_name == 'Mq9 Gas':
                sensor_name = 'MQ9 Gas (CO, LPG, CH4)'
            
            items_html += f"""
            <div class="alert-item">
                <div class="sensor-name">{sensor_name}</div>
                <div>Current Value: <span class="value">{alert['value']}</span></div>
                <div>Safety Threshold: <span class="threshold">{alert['threshold']}</span></div>
                <div>Excess: <span class="value">{alert['value'] - alert['threshold']}</span></div>
                <div>Alert Level: <span class="value">DANGER</span></div>
            </div>
            """
        
        return items_html

# Example usage
if __name__ == "__main__":
    email_system = EmailAlertSystem()
    
    # Test alert
    test_alerts = [
        {
            'sensor': 'mq2_gas',
            'value': 350,
            'threshold': 300,
            'timestamp': datetime.now().isoformat()
        }
    ]
    
    email_system.send_alert(test_alerts)
