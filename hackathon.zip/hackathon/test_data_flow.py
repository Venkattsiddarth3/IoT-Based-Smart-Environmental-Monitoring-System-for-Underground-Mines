#!/usr/bin/env python3
"""
Test script to verify data flow from HiveMQ to Web UI
"""

import paho.mqtt.client as mqtt
import json
import time
from datetime import datetime

# MQTT Configuration
MQTT_SERVER = "c2d3d6cc30c0464cbfb2273abea14ca6.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USER = "Rahul_Tej123"
MQTT_PASSWORD = "SMDRizwan9"
MQTT_TOPIC = "mine/sensors/data"

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("✅ Connected to HiveMQ Cloud!")
        print(f"📡 Subscribing to topic: {MQTT_TOPIC}")
        client.subscribe(MQTT_TOPIC)
        print("⏳ Waiting for sensor data from ESP32...")
        print("   (Make sure your ESP32 is running and sending data)")
    else:
        print(f"❌ Failed to connect. Return code: {rc}")

def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode())
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        print(f"\n📊 [{timestamp}] Sensor Data Received:")
        print(f"   MQ2 Gas: {data.get('MQ2', 'N/A')} ppm (Alert: {data.get('MQ2Alert', 'N/A')})")
        print(f"   MQ9 Gas: {data.get('MQ9', 'N/A')} ppm (Alert: {data.get('MQ9Alert', 'N/A')})")
        print(f"   Temperature: {data.get('Temperature', 'N/A')} °C")
        print(f"   Humidity: {data.get('Humidity', 'N/A')} %")
        print(f"   Noise: {data.get('Noise', 'N/A')} dB")
        print("   " + "="*40)
        
        # Check if data is being sent to web UI
        print("   ✅ This data should appear in your web UI!")
        
    except Exception as e:
        print(f"❌ Error parsing message: {e}")

def test_data_flow():
    print("🔍 Testing Data Flow: ESP32 → HiveMQ → Web UI")
    print("=" * 60)
    
    # Create MQTT client
    client = mqtt.Client()
    client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
    client.tls_set()
    
    # Set callbacks
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        print("🔗 Connecting to HiveMQ Cloud...")
        client.connect(MQTT_SERVER, MQTT_PORT, 60)
        client.loop_start()
        
        print("\n📋 Instructions:")
        print("1. Make sure your ESP32 is running and connected to WiFi")
        print("2. Check that ESP32 is sending data to HiveMQ cloud")
        print("3. Open your web UI at http://localhost:5001")
        print("4. Watch for real-time data updates")
        print("\n⏳ Monitoring for 60 seconds...")
        print("   Press Ctrl+C to stop early")
        
        # Monitor for 60 seconds
        time.sleep(60)
        
    except KeyboardInterrupt:
        print("\n🛑 Stopping test...")
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        client.loop_stop()
        client.disconnect()
        print("✅ Test completed")

if __name__ == "__main__":
    test_data_flow()
