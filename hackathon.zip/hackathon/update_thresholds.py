#!/usr/bin/env python3
"""
Update sensor thresholds based on actual data patterns
"""

import sqlite3
import os

def analyze_data_patterns():
    """Analyze actual data to set realistic thresholds"""
    print("📊 ANALYZING DATA PATTERNS FOR THRESHOLD SETTING")
    print("=" * 60)
    
    try:
        conn = sqlite3.connect('sensor_data.db')
        cursor = conn.cursor()
        
        # Get recent data (last 100 records)
        cursor.execute('''
            SELECT mq2_gas, mq9_gas, temperature, humidity, noise 
            FROM sensor_readings 
            ORDER BY timestamp DESC 
            LIMIT 100
        ''')
        
        data = cursor.fetchall()
        
        if not data:
            print("❌ No data found in database")
            return
        
        # Calculate statistics
        mq2_values = [row[0] for row in data if row[0] is not None]
        mq9_values = [row[1] for row in data if row[1] is not None]
        temp_values = [row[2] for row in data if row[2] is not None]
        humidity_values = [row[3] for row in data if row[3] is not None]
        noise_values = [row[4] for row in data if row[4] is not None]
        
        print("📈 CURRENT DATA ANALYSIS:")
        print(f"   MQ2 Gas: Min={min(mq2_values):.1f}, Max={max(mq2_values):.1f}, Avg={sum(mq2_values)/len(mq2_values):.1f}")
        print(f"   MQ9 Gas: Min={min(mq9_values):.1f}, Max={max(mq9_values):.1f}, Avg={sum(mq9_values)/len(mq9_values):.1f}")
        print(f"   Temperature: Min={min(temp_values):.1f}, Max={max(temp_values):.1f}, Avg={sum(temp_values)/len(temp_values):.1f}")
        print(f"   Humidity: Min={min(humidity_values):.1f}, Max={max(humidity_values):.1f}, Avg={sum(humidity_values)/len(humidity_values):.1f}")
        print(f"   Noise: Min={min(noise_values):.1f}, Max={max(noise_values):.1f}, Avg={sum(noise_values)/len(noise_values):.1f}")
        
        # Set realistic thresholds based on data patterns
        new_thresholds = {
            'mq2_gas': max(50, max(mq2_values) * 1.5),      # 1.5x max observed
            'mq9_gas': max(30, max(mq9_values) * 1.5),      # 1.5x max observed
            'temperature': max(40, max(temp_values) + 5),    # 5°C above max observed
            'humidity': max(90, max(humidity_values) + 10),  # 10% above max observed
            'noise': max(50, max(noise_values) * 2)          # 2x max observed
        }
        
        print("\n🎯 RECOMMENDED THRESHOLDS:")
        print("=" * 40)
        for sensor, threshold in new_thresholds.items():
            print(f"   {sensor}: {threshold:.1f}")
        
        return new_thresholds
        
    except Exception as e:
        print(f"❌ Error analyzing data: {e}")
        return None
    finally:
        if 'conn' in locals():
            conn.close()

def update_app_thresholds(new_thresholds):
    """Update the thresholds in app.py"""
    if not new_thresholds:
        return False
    
    try:
        # Read current app.py
        with open('app.py', 'r') as f:
            content = f.read()
        
        # Create new threshold section
        new_threshold_section = f"""# Sensor Thresholds (Danger Levels) - Updated based on actual data
THRESHOLDS = {{
    'mq2_gas': {new_thresholds['mq2_gas']:.1f},      # ppm - Methane, LPG, Propane
    'mq9_gas': {new_thresholds['mq9_gas']:.1f},      # ppm - CO, LPG, CH4
    'temperature': {new_thresholds['temperature']:.1f},   # °C - High temperature
    'humidity': {new_thresholds['humidity']:.1f},      # % - High humidity
    'noise': {new_thresholds['noise']:.1f}          # dB - High noise level
}}"""
        
        # Replace the threshold section
        import re
        pattern = r'# Sensor Thresholds \(Danger Levels\).*?}'
        updated_content = re.sub(pattern, new_threshold_section, content, flags=re.DOTALL)
        
        # Write back to file
        with open('app.py', 'w') as f:
            f.write(updated_content)
        
        print("✅ Thresholds updated in app.py")
        return True
        
    except Exception as e:
        print(f"❌ Error updating app.py: {e}")
        return False

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("🎯 THRESHOLD OPTIMIZATION")
    print("=" * 60)
    
    # Analyze data patterns
    new_thresholds = analyze_data_patterns()
    
    if new_thresholds:
        print("\n🔄 UPDATING THRESHOLDS...")
        if update_app_thresholds(new_thresholds):
            print("✅ Thresholds updated successfully!")
            print("\n📋 NEW THRESHOLDS:")
            for sensor, threshold in new_thresholds.items():
                print(f"   {sensor}: {threshold:.1f}")
            
            print("\n🚀 Restart the system to apply new thresholds:")
            print("   1. Stop current system (Ctrl+C)")
            print("   2. Run: python3 run.py")
            print("   3. Open: http://localhost:5001")
        else:
            print("❌ Failed to update thresholds")
    else:
        print("❌ Could not analyze data patterns")

if __name__ == "__main__":
    main()
