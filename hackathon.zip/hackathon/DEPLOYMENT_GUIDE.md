# Deployment Guide - Underground Mining Environmental Monitor

## Quick Start

### 1. Install Dependencies
```bash
# Install Python dependencies
pip3 install -r requirements.txt

# Or if you prefer pip
pip install -r requirements.txt
```

### 2. Configure Environment (Optional)
```bash
# Copy environment template
cp env_example.txt .env

# Edit .env file with your credentials
nano .env
```

### 3. Run the System
```bash
# Option 1: Use the launch script
python3 run.py

# Option 2: Run directly
python3 app.py
```

### 4. Access the Dashboard
Open your web browser and go to: `http://localhost:5000`

## System Requirements

### Hardware
- **ESP32 Development Board**
- **MQ2 Gas Sensor** (Methane, LPG, Propane)
- **MQ9 Gas Sensor** (CO, LPG, CH4)
- **Heart Rate Sensor** (Pulse sensor or similar)
- **DHT11 Temperature & Humidity Sensor**
- **Noise Sensor** (Sound level sensor)
- **Jumper wires and breadboard**

### Software
- **Python 3.8+**
- **Arduino IDE** (for ESP32 programming)
- **Web browser** (Chrome, Firefox, Safari, Edge)

## ESP32 Setup

### 1. Install Arduino IDE
- Download from: https://www.arduino.cc/en/software
- Install ESP32 board support package

### 2. Install Required Libraries
In Arduino IDE, go to Tools → Manage Libraries and install:
- **WiFi** (built-in)
- **PubSubClient** by Nick O'Leary
- **ArduinoJson** by Benoit Blanchon
- **DHT sensor library** by Adafruit
- **Wire** (built-in)

### 3. Upload Code
- Open `ESP32_Arduino_Code.ino` in Arduino IDE
- Configure WiFi credentials in the code
- Select your ESP32 board and port
- Upload the code

### 4. Hardware Connections
```
ESP32 Pin    →    Sensor
A0          →    MQ2 Gas Sensor (Analog)
A1          →    MQ9 Gas Sensor (Analog)
A2          →    Noise Sensor (Analog)
D2          →    Heart Rate Sensor (Digital)
D4          →    DHT11 Data Pin
3.3V        →    VCC for all sensors
GND         →    GND for all sensors
```

## Web Interface Features

### Real-time Dashboard
- **Live sensor readings** with color-coded status
- **Trend indicators** (arrows showing increase/decrease)
- **Progress bars** showing threshold proximity
- **Connection status** monitoring

### Data Visualization
- **Interactive charts** with multiple sensor overlays
- **Historical data table** with timestamps
- **Real-time updates** via WebSocket connection

### Alert System
- **Visual alerts** with danger banners
- **Email notifications** (HTML formatted)
- **Telegram alerts** (instant messaging)
- **Threshold monitoring** with configurable limits

## Configuration

### Sensor Thresholds
Default safety thresholds (modify in `app.py`):
```python
THRESHOLDS = {
    'mq2_gas': 300,      # ppm - Methane, LPG, Propane
    'mq9_gas': 200,      # ppm - CO, LPG, CH4
    'heart_rate': 100,   # bpm - High heart rate
    'temperature': 35,   # °C - High temperature
    'humidity': 80,      # % - High humidity
    'noise': 85          # dB - High noise level
}
```

### MQTT Settings
Pre-configured for your HiveMQ cloud:
- **Server**: `c2d3d6cc30c0464cbfb2273abea14ca6.s1.eu.hivemq.cloud`
- **Port**: `8883` (Secure TLS)
- **Username**: `Rahul_Tej123`
- **Password**: `SMDRizwan9`
- **Topic**: `sensor/data`

## Alert Configuration

### Email Alerts
1. **Gmail Setup**:
   - Enable 2-factor authentication
   - Generate App Password
   - Use App Password in `.env` file

2. **Other Email Providers**:
   - Update SMTP server and port in `.env`
   - Use appropriate credentials

### Telegram Alerts
1. **Create Bot**:
   - Message @BotFather on Telegram
   - Create new bot with `/newbot`
   - Get bot token

2. **Get Chat ID**:
   - Message @userinfobot
   - Get your chat ID
   - Add both to `.env` file

## Testing the System

### 1. Test MQTT Connection
- Check console output for "Connected to MQTT Broker!"
- Verify ESP32 is publishing data

### 2. Test Web Interface
- Open `http://localhost:5000`
- Check connection status shows "Connected"
- Verify sensor data appears

### 3. Test Alerts
- Temporarily lower thresholds in code
- Trigger alert conditions
- Verify email/Telegram notifications

## Troubleshooting

### Common Issues

**MQTT Connection Failed**
- Check internet connection
- Verify HiveMQ credentials
- Ensure ESP32 is connected to WiFi

**No Sensor Data**
- Check ESP32 serial monitor
- Verify sensor connections
- Check JSON data format

**Email Alerts Not Working**
- Verify `.env` configuration
- Check SMTP credentials
- Test with Gmail App Password

**Web Interface Not Loading**
- Check if port 5000 is available
- Verify all dependencies installed
- Check console for error messages

### Debug Mode
Run with debug enabled:
```bash
python3 app.py
```
Look for detailed error messages in console.

## Production Deployment

### Security Considerations
- Change default passwords
- Use proper SSL certificates
- Implement user authentication
- Secure database access

### Performance Optimization
- Use production WSGI server (Gunicorn)
- Implement database connection pooling
- Add caching for historical data
- Optimize chart rendering

### Monitoring
- Set up log monitoring
- Implement health checks
- Monitor system resources
- Track alert response times

## Support

For technical support:
1. Check this deployment guide
2. Review README.md for detailed documentation
3. Check console logs for error messages
4. Verify all hardware connections
5. Test individual components

## Safety Notes

⚠️ **Important Safety Information**:
- This system is for monitoring assistance only
- Always follow proper mining safety protocols
- Have backup monitoring systems in place
- Regularly calibrate and test sensors
- Maintain emergency response procedures

