#!/usr/bin/env python3
"""
Setup email configuration with App Password
"""

import os

def create_env_file():
    """Create .env file with proper configuration"""
    print("📄 CREATING .env FILE")
    print("=" * 25)
    
    env_content = """# Email Configuration
EMAIL_SMTP_SERVER=smtp.gmail.com
EMAIL_SMTP_PORT=587
EMAIL_USER=rangajal@gitam.in
EMAIL_PASSWORD=YOUR_16_CHARACTER_APP_PASSWORD_HERE
RECIPIENT_EMAILS=sgnana@gitam.in,vnuggu@gitam.in

# Telegram Configuration
TELEGRAM_BOT_TOKEN=8387035130
TELEGRAM_CHAT_ID=y8387035130:AAFlRy0W7e7NvdbFdcF5VW6k_X_m4Gzl8cc
"""
    
    try:
        with open('.env', 'w') as f:
            f.write(env_content)
        print("✅ .env file created successfully!")
        print("📝 Now you need to:")
        print("1. Get your Gmail App Password")
        print("2. Replace 'YOUR_16_CHARACTER_APP_PASSWORD_HERE' with your actual App Password")
        print("3. Save the file")
        return True
    except Exception as e:
        print(f"❌ Error creating .env file: {e}")
        return False

def show_next_steps():
    """Show what to do next"""
    print("\n🔧 NEXT STEPS:")
    print("=" * 15)
    print("1. 🌐 Go to: https://myaccount.google.com/")
    print("2. 🔐 Sign in with: rangajal@gitam.in")
    print("3. ⚙️  Click 'Security' → 'App passwords'")
    print("4. 📱 Select 'Mail' and copy the 16-character password")
    print("5. 📝 Edit .env file and replace YOUR_16_CHARACTER_APP_PASSWORD_HERE")
    print("6. 🧪 Test: python3 test_email_simple.py")
    print("7. 🚀 Start: python3 run.py")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📧 EMAIL SETUP")
    print("=" * 40)
    print()
    
    success = create_env_file()
    
    if success:
        show_next_steps()
        print("\n🎯 EMAIL RECIPIENTS:")
        print("   - sgnana@gitam.in")
        print("   - vnuggu@gitam.in")
        print("\n🌡️  TEMPERATURE THRESHOLD: 26°C")
        print("📧 Emails will be sent when temperature > 26°C")

if __name__ == "__main__":
    main()
