/*
 * Underground Mining Environmental Monitoring System
 * ESP32 Arduino Code for Sensor Data Collection
 * 
 * This code reads data from various sensors and publishes to HiveMQ Cloud
 * 
 * Required Libraries:
 * - WiFi
 * - PubSubClient
 * - ArduinoJson
 * - DHT sensor library
 * - Wire (for I2C sensors)
 * 
 * Hardware Connections:
 * - MQ2 Gas Sensor: Analog Pin A0
 * - MQ9 Gas Sensor: Analog Pin A1
 * - Heart Rate Sensor: Digital Pin 2
 * - DHT11: Digital Pin 4
 * - Noise Sensor: Analog Pin A2
 */

#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

// WiFi Configuration
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// MQTT Configuration
const char* mqtt_server = "c2d3d6cc30c0464cbfb2273abea14ca6.s1.eu.hivemq.cloud";
const int mqtt_port = 8883;   // Secure TLS Port
const char* mqtt_user = "Rahul_Tej123";       // Your HiveMQ username
const char* mqtt_password = "SMDRizwan9";     // Your HiveMQ password
const char* mqtt_topic = "sensor/data";

// Sensor Pins
#define MQ2_PIN A0
#define MQ9_PIN A1
#define HEART_RATE_PIN 2
#define DHT_PIN 4
#define NOISE_PIN A2
#define DHT_TYPE DHT11

// Initialize objects
WiFiClientSecure espClient;
PubSubClient client(espClient);
DHT dht(DHT_PIN, DHT_TYPE);

// Variables for sensor readings
float mq2_gas = 0;
float mq9_gas = 0;
float heart_rate = 0;
float temperature = 0;
float humidity = 0;
float noise = 0;

// Timing variables
unsigned long lastReading = 0;
const unsigned long readingInterval = 5000; // 5 seconds

void setup() {
  Serial.begin(115200);
  
  // Initialize sensors
  dht.begin();
  pinMode(HEART_RATE_PIN, INPUT);
  
  // Connect to WiFi
  setupWiFi();
  
  // Setup MQTT
  setupMQTT();
  
  Serial.println("Underground Mining Environmental Monitor Started");
}

void loop() {
  // Check MQTT connection
  if (!client.connected()) {
    reconnectMQTT();
  }
  client.loop();
  
  // Read sensors every 5 seconds
  if (millis() - lastReading >= readingInterval) {
    readSensors();
    publishData();
    lastReading = millis();
  }
  
  delay(100);
}

void setupWiFi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);
  
  WiFi.begin(ssid, password);
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

void setupMQTT() {
  espClient.setInsecure(); // For testing - use proper certificates in production
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();
}

void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    
    if (client.connect("ESP32Client", mqtt_user, mqtt_password)) {
      Serial.println("connected");
      client.subscribe("sensor/commands");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void readSensors() {
  // Read MQ2 Gas Sensor (Methane, LPG, Propane)
  int mq2_raw = analogRead(MQ2_PIN);
  mq2_gas = map(mq2_raw, 0, 4095, 0, 1000); // Convert to ppm range
  
  // Read MQ9 Gas Sensor (CO, LPG, CH4)
  int mq9_raw = analogRead(MQ9_PIN);
  mq9_gas = map(mq9_raw, 0, 4095, 0, 1000); // Convert to ppm range
  
  // Read Heart Rate Sensor (simulated - replace with actual sensor code)
  heart_rate = random(60, 120); // Simulate heart rate between 60-120 bpm
  
  // Read DHT11 Temperature and Humidity
  temperature = dht.readTemperature();
  humidity = dht.readHumidity();
  
  // Check if DHT readings are valid
  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read from DHT sensor!");
    temperature = 25.0; // Default values
    humidity = 50.0;
  }
  
  // Read Noise Sensor
  int noise_raw = analogRead(NOISE_PIN);
  noise = map(noise_raw, 0, 4095, 30, 120); // Convert to dB range
  
  // Print readings to Serial
  Serial.println("=== Sensor Readings ===");
  Serial.print("MQ2 Gas: "); Serial.print(mq2_gas); Serial.println(" ppm");
  Serial.print("MQ9 Gas: "); Serial.print(mq9_gas); Serial.println(" ppm");
  Serial.print("Heart Rate: "); Serial.print(heart_rate); Serial.println(" bpm");
  Serial.print("Temperature: "); Serial.print(temperature); Serial.println(" °C");
  Serial.print("Humidity: "); Serial.print(humidity); Serial.println(" %");
  Serial.print("Noise: "); Serial.print(noise); Serial.println(" dB");
  Serial.println("=======================");
}

void publishData() {
  // Create JSON document
  DynamicJsonDocument doc(1024);
  
  doc["mq2_gas"] = mq2_gas;
  doc["mq9_gas"] = mq9_gas;
  doc["heart_rate"] = heart_rate;
  doc["temperature"] = temperature;
  doc["humidity"] = humidity;
  doc["noise"] = noise;
  doc["timestamp"] = millis();
  
  // Serialize JSON
  char jsonBuffer[512];
  serializeJson(doc, jsonBuffer);
  
  // Publish to MQTT
  if (client.publish(mqtt_topic, jsonBuffer)) {
    Serial.println("Data published successfully");
  } else {
    Serial.println("Failed to publish data");
  }
}

/*
 * Additional Functions for Real Sensors:
 * 
 * For Heart Rate Sensor (Pulse Sensor):
 * - Use interrupt on heart rate pin
 * - Calculate BPM from pulse intervals
 * 
 * For Gas Sensors:
 * - Calibrate sensors for accurate readings
 * - Use proper conversion formulas
 * - Consider temperature compensation
 * 
 * For Noise Sensor:
 * - Use proper sound level calculation
 * - Consider frequency weighting (A-weighting)
 * - Calibrate for accurate dB readings
 */

