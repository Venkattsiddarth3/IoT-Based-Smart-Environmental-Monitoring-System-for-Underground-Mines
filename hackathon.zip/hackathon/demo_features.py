#!/usr/bin/env python3
"""
Demo script to showcase all features of the Underground Mining Monitor
"""

import json
import time
from datetime import datetime

def demo_data_format():
    """Show the data format being processed"""
    print("🎯 DEMO: Data Format Processing")
    print("=" * 50)
    
    # Your actual data format
    raw_data = {
        "MQ2": 773,
        "MQ9": 752,
        "Noise": 107,
        "Humidity": 63.00,
        "Temperature": 28.30,
        "MQ2Alert": 0,
        "MQ9Alert": 0
    }
    
    print("📥 Raw Data from HiveMQ:")
    print(json.dumps(raw_data, indent=2))
    
    # Converted format for web UI
    converted_data = {
        'mq2_gas': raw_data.get('MQ2', 0),
        'mq9_gas': raw_data.get('MQ9', 0),
        'heart_rate': 75,  # Default value
        'temperature': raw_data.get('Temperature', 0),
        'humidity': raw_data.get('Humidity', 0),
        'noise': raw_data.get('Noise', 0),
        'mq2_alert': raw_data.get('MQ2Alert', 0),
        'mq9_alert': raw_data.get('MQ9Alert', 0)
    }
    
    print("\n📤 Converted Data for Web UI:")
    print(json.dumps(converted_data, indent=2))
    print("\n✅ Data conversion successful!")

def demo_thresholds():
    """Show threshold monitoring"""
    print("\n🚨 DEMO: Threshold Monitoring")
    print("=" * 50)
    
    thresholds = {
        'mq2_gas': 300,      # ppm - Methane, LPG, Propane
        'mq9_gas': 200,      # ppm - CO, LPG, CH4
        'heart_rate': 100,   # bpm - High heart rate
        'temperature': 35,   # °C - High temperature
        'humidity': 80,      # % - High humidity
        'noise': 85          # dB - High noise level
    }
    
    print("📊 Safety Thresholds:")
    for sensor, threshold in thresholds.items():
        print(f"   {sensor}: {threshold}")
    
    # Simulate dangerous readings
    dangerous_data = {
        'mq2_gas': 450,  # Above threshold
        'mq9_gas': 250,  # Above threshold
        'temperature': 38,  # Above threshold
        'noise': 95  # Above threshold
    }
    
    print("\n⚠️ Simulating Dangerous Readings:")
    alerts = []
    for sensor, value in dangerous_data.items():
        if sensor in thresholds and value > thresholds[sensor]:
            alerts.append({
                'sensor': sensor,
                'value': value,
                'threshold': thresholds[sensor]
            })
            print(f"   🚨 {sensor}: {value} (Threshold: {thresholds[sensor]}) - ALERT!")
    
    print(f"\n📧 {len(alerts)} alerts would be sent via email and Telegram")

def demo_web_features():
    """Show web UI features"""
    print("\n🌐 DEMO: Web UI Features")
    print("=" * 50)
    
    features = [
        "📊 Real-time sensor value displays",
        "📈 Interactive charts with trend indicators",
        "🎨 Color-coded status cards (Green/Yellow/Red)",
        "⬆️⬇️ Trend arrows showing increase/decrease",
        "📊 Progress bars showing threshold proximity",
        "🚨 Alert status indicators for gas sensors",
        "📱 Responsive design for mobile/tablet",
        "🔄 Auto-refreshing data every 5 seconds",
        "📋 Historical data table with timestamps",
        "🔔 Visual alert banners for danger",
        "📧 Email notifications for threshold breaches",
        "📱 Telegram instant messaging alerts"
    ]
    
    for feature in features:
        print(f"   {feature}")
    
    print("\n🎯 Web UI Components:")
    print("   • Header with connection status")
    print("   • 6 sensor cards with real-time values")
    print("   • Live charts showing data trends")
    print("   • Historical data table")
    print("   • Alert banners for emergencies")

def demo_alert_system():
    """Show alert system features"""
    print("\n📧 DEMO: Alert System")
    print("=" * 50)
    
    print("📧 Email Alerts:")
    print("   • Professional HTML formatting")
    print("   • Sent to: sgnana@gitam.in, vnuggu@gitam.in")
    print("   • Includes sensor values and thresholds")
    print("   • Emergency action recommendations")
    
    print("\n📱 Telegram Alerts:")
    print("   • Instant mobile notifications")
    print("   • Real-time danger alerts")
    print("   • Formatted for quick reading")
    
    print("\n🌐 Web Alerts:")
    print("   • Visual alert banners")
    print("   • Color-coded sensor cards")
    print("   • Auto-dismissing notifications")
    print("   • Real-time status updates")

def demo_data_flow():
    """Show complete data flow"""
    print("\n🔄 DEMO: Complete Data Flow")
    print("=" * 50)
    
    flow_steps = [
        "1. ESP32 reads sensors (MQ2, MQ9, DHT11, Noise)",
        "2. ESP32 sends JSON data to HiveMQ Cloud",
        "3. Python backend receives data via MQTT",
        "4. Data is processed and stored in SQLite database",
        "5. WebSocket sends data to web browser",
        "6. JavaScript updates UI with real-time values",
        "7. Charts are updated with new data points",
        "8. Threshold monitoring checks for danger",
        "9. Alerts sent via email/Telegram if needed",
        "10. Historical data is preserved for analysis"
    ]
    
    for step in flow_steps:
        print(f"   {step}")
        time.sleep(0.5)  # Simulate processing time
    
    print("\n✅ Complete data flow demonstrated!")

def main():
    print("🏭 UNDERGROUND MINING ENVIRONMENTAL MONITOR")
    print("🎯 COMPLETE FEATURE DEMONSTRATION")
    print("=" * 60)
    
    demo_data_format()
    demo_thresholds()
    demo_web_features()
    demo_alert_system()
    demo_data_flow()
    
    print("\n" + "=" * 60)
    print("🎉 ALL FEATURES DEMONSTRATED SUCCESSFULLY!")
    print("\n📋 To see everything in action:")
    print("   1. Run: python3 run.py")
    print("   2. Open: http://localhost:5001")
    print("   3. Watch real-time data from your ESP32!")
    print("\n🚀 Your mining monitoring system is ready!")

if __name__ == "__main__":
    main()
