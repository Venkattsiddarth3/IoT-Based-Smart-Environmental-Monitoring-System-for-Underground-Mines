#!/usr/bin/env python3
"""
Setup mobile numbers for SMS alerts
Easy configuration - just add mobile numbers
"""

def show_mobile_setup():
    """Show how to add mobile numbers"""
    print("📱 MOBILE NUMBERS SETUP FOR SMS ALERTS")
    print("=" * 50)
    print()
    print("🔧 HOW TO ADD YOUR MOBILE NUMBERS:")
    print("-" * 40)
    print("1. 📝 Edit app.py file")
    print("2. 🔍 Find this section in send_sms_alert method:")
    print("   recipient_numbers = [")
    print("       '+919876543210',  # Replace with your mobile")
    print("       '+919876543211'   # Replace with another mobile")
    print("   ]")
    print("3. 📱 Replace with actual mobile numbers")
    print("4. 🌍 Use format: +91XXXXXXXXXX (with country code)")
    print()
    print("📋 EXAMPLE:")
    print("   recipient_numbers = [")
    print("       '+919876543210',  # Your mobile")
    print("       '+919876543211',  # Friend's mobile")
    print("       '+919876543212'   # Family member's mobile")
    print("   ]")
    print()
    print("💰 COST: FREE (using TextBelt service)")
    print("📱 LIMIT: 1 SMS per day per number (free tier)")
    print("🚀 EASY: No complex authentication required")

def test_sms_system():
    """Test SMS system"""
    print("\n🧪 TESTING SMS SYSTEM")
    print("=" * 25)
    
    try:
        import requests
        
        # Test data
        test_message = "🧪 TEST SMS from Underground Mining Monitor"
        test_phone = "+919876543210"  # Replace with your actual number
        
        data = {
            'phone': test_phone,
            'message': test_message,
            'key': 'textbelt'
        }
        
        print(f"📱 Sending test SMS to {test_phone}...")
        response = requests.post('https://textbelt.com/text', data=data, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print("✅ Test SMS sent successfully!")
                print("📱 Check your mobile for the test message")
            else:
                print(f"❌ Test SMS failed: {result.get('error', 'Unknown error')}")
        else:
            print(f"❌ HTTP error {response.status_code}")
            
    except Exception as e:
        print(f"❌ Test failed: {e}")

def show_alert_system():
    """Show complete alert system"""
    print("\n🚨 COMPLETE ALERT SYSTEM")
    print("=" * 30)
    print("📧 Email Alerts: sgnana@gitam.in, vnuggu@gitam.in")
    print("📱 SMS Alerts: Your mobile numbers")
    print("💬 Telegram Alerts: Configured")
    print("🌐 Web Alerts: Real-time on http://localhost:5001")
    print()
    print("🌡️  TEMPERATURE THRESHOLD: 26°C")
    print("📧 When temperature > 26°C:")
    print("   - Email sent to reviewers")
    print("   - SMS sent to mobile numbers")
    print("   - Web alert displayed")
    print("   - Telegram notification sent")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("📱 SMS ALERT SETUP")
    print("=" * 50)
    
    show_mobile_setup()
    test_sms_system()
    show_alert_system()
    
    print("\n" + "=" * 50)
    print("🎯 NEXT STEPS:")
    print("1. Add your mobile numbers to app.py")
    print("2. Test SMS: python3 simple_sms_alerts.py")
    print("3. Start system: python3 run.py")
    print("4. Access: http://localhost:5001")
    print("5. SMS alerts will be sent when temperature > 26°C")

if __name__ == "__main__":
    main()
