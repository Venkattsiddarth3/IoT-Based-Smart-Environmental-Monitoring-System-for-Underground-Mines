// Mining Environmental Monitor - Frontend JavaScript

class MiningMonitor {
    constructor() {
        this.socket = null;
        this.chart = null;
        this.lastReadings = {};
        this.thresholds = {};
        this.chartData = {
            labels: [],
            datasets: []
        };
        this.maxDataPoints = 20;
        
        this.init();
    }

    init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.initializeComponents();
            });
        } else {
            this.initializeComponents();
        }
    }

    initializeComponents() {
        this.initializeChart();
        this.initializeSocket();
        this.loadThresholds();
        this.loadHistoricalData();
        this.loadCurrentData();
        this.setupEventListeners();
        
        // Initialize MQTT status display
        this.initializeMQTTStatus();
        
        console.log('Mining Monitor initialized successfully');
    }

    loadCurrentData() {
        // Load current data into Latest Reading box
        fetch('/api/current_data')
            .then(response => response.json())
            .then(data => {
                console.log('📊 Loading current data into Latest Reading Box:', data);
                this.updateLatestReadingBox(data);
            })
            .catch(error => console.error('Error loading current data:', error));
    }

    initializeSocket() {
        this.socket = io();
        
        this.socket.on('connect', () => {
            console.log('Connected to server');
            this.updateConnectionStatus(true);
            // Request initial status
            this.socket.emit('request_status');
            // Request MQTT status
            setTimeout(() => {
                this.socket.emit('request_status');
            }, 1000);
        });

        this.socket.on('disconnect', () => {
            console.log('Disconnected from server');
            this.updateConnectionStatus(false);
        });

        this.socket.on('status', (data) => {
            console.log('Status received:', data);
            this.updateConnectionStatus(data.connected, data.mqtt_connected);
            // Update MQTT status display
            if (data.mqtt_connected !== undefined) {
                this.updateMQTTStatusDisplay(data.mqtt_connected);
            }
        });

        this.socket.on('mqtt_status', (data) => {
            console.log('MQTT Status:', data);
            this.updateMQTTStatus(data.connected, data.error);
        });

        this.socket.on('sensor_data', (data) => {
            console.log('Received sensor data:', data);
            this.updateSensorDisplays(data);
            this.updateChart(data);
            this.updateLastUpdateTime();
        });

        this.socket.on('alert', (data) => {
            console.log('Received alert:', data);
            this.showAlert(data.alerts);
        });
    }

    initializeChart() {
        const ctx = document.getElementById('sensorChart').getContext('2d');
        
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'MQ2 Gas (ppm)',
                        data: [],
                        borderColor: '#007bff',
                        backgroundColor: 'rgba(0, 123, 255, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'MQ9 Gas (ppm)',
                        data: [],
                        borderColor: '#ffc107',
                        backgroundColor: 'rgba(255, 193, 7, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Temperature (°C)',
                        data: [],
                        borderColor: '#17a2b8',
                        backgroundColor: 'rgba(23, 162, 184, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Humidity (%)',
                        data: [],
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Noise (dB)',
                        data: [],
                        borderColor: '#6c757d',
                        backgroundColor: 'rgba(108, 117, 125, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Sensor Values'
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Real-time Sensor Data Trends'
                    }
                }
            }
        });
    }

    loadThresholds() {
        fetch('/api/thresholds')
            .then(response => response.json())
            .then(data => {
                this.thresholds = data;
                this.updateThresholdDisplays();
            })
            .catch(error => console.error('Error loading thresholds:', error));
    }

    loadHistoricalData() {
        fetch('/api/historical_data')
            .then(response => response.json())
            .then(data => {
                this.populateHistoricalTable(data);
                this.populateChartWithHistoricalData(data);
            })
            .catch(error => console.error('Error loading historical data:', error));
    }

    populateChartWithHistoricalData(data) {
        if (!this.chart || !data || data.length === 0) return;

        // Take the last 20 records for initial chart data
        const recentData = data.slice(-this.maxDataPoints);
        
        // Clear existing data
        this.chart.data.labels = [];
        this.chart.data.datasets.forEach(dataset => {
            dataset.data = [];
        });

        // Populate with historical data
        recentData.forEach(record => {
            const timeLabel = new Date(record.timestamp).toLocaleTimeString();
            this.chart.data.labels.push(timeLabel);

            // Add data to each dataset
            this.chart.data.datasets[0].data.push(record.mq2_gas || 0); // MQ2
            this.chart.data.datasets[1].data.push(record.mq9_gas || 0); // MQ9
            this.chart.data.datasets[2].data.push(record.temperature || 0); // Temperature
            this.chart.data.datasets[3].data.push(record.humidity || 0); // Humidity
            this.chart.data.datasets[4].data.push(record.noise || 0); // Noise
        });

        this.chart.update('none');
        console.log('Chart populated with historical data:', recentData.length, 'records');
    }

    updateThresholdDisplays() {
        // Map sensor names to HTML element IDs
        const thresholdMapping = {
            'mq2_gas': 'mq2-threshold',
            'mq9_gas': 'mq9-threshold', 
            'temperature': 'temp-threshold',
            'humidity': 'humidity-threshold',
            'noise': 'noise-threshold'
        };

        Object.keys(this.thresholds).forEach(sensor => {
            const elementId = thresholdMapping[sensor];
            if (elementId) {
                const element = document.getElementById(elementId);
                if (element) {
                    element.textContent = this.thresholds[sensor].toFixed(1);
                }
            }
        });
    }

    updateSensorDisplays(data) {
        // Update latest reading box first
        this.updateLatestReadingBox(data);
        
        Object.keys(data).forEach(sensor => {
            const value = data[sensor];
            const valueElement = document.getElementById(`${sensor}_value`);
            const cardElement = document.getElementById(`${sensor}_card`);
            const progressElement = document.getElementById(`${sensor}_progress`);
            const trendElement = document.getElementById(`${sensor}_trend`);

            if (valueElement) {
                valueElement.textContent = value.toFixed(1);
            }

            // Update trend indicator
            if (trendElement && this.lastReadings[sensor] !== undefined) {
                const trend = this.calculateTrend(this.lastReadings[sensor], value);
                this.updateTrendIndicator(trendElement, trend);
            }

            // Update progress bar and card status
            if (progressElement && cardElement && this.thresholds[sensor]) {
                const percentage = Math.min((value / this.thresholds[sensor]) * 100, 100);
                progressElement.style.width = `${percentage}%`;
                
                // Update card status
                cardElement.classList.remove('safe', 'warning', 'danger');
                if (value > this.thresholds[sensor]) {
                    cardElement.classList.add('danger');
                    progressElement.className = 'progress-bar danger';
                } else if (value > this.thresholds[sensor] * 0.8) {
                    cardElement.classList.add('warning');
                    progressElement.className = 'progress-bar warning';
                } else {
                    cardElement.classList.add('safe');
                    progressElement.className = 'progress-bar safe';
                }
            }
            
            // Update alert status for gas sensors
            if (sensor === 'mq2_gas' || sensor === 'mq9_gas') {
                this.updateAlertStatus(sensor, data);
            }
        });

        this.lastReadings = { ...data };
    }

    updateLatestReadingBox(data) {
        console.log('📊 Updating Latest Reading Box with data:', data);
        
        // Update latest reading values
        const latestElements = {
            'latest-mq2': data.mq2_gas,
            'latest-mq9': data.mq9_gas,
            'latest-temperature': data.temperature,
            'latest-humidity': data.humidity,
            'latest-noise': data.noise
        };

        console.log('📊 Latest Elements to update:', latestElements);

        Object.keys(latestElements).forEach(elementId => {
            const element = document.getElementById(elementId);
            const value = latestElements[elementId];
            
            console.log(`📊 Updating ${elementId}: ${value}`);
            
            if (element && value !== undefined && value !== null) {
                element.textContent = value.toFixed(1);
                console.log(`✅ Updated ${elementId} to ${value.toFixed(1)}`);
                
                // Add animation class for new reading
                element.parentElement.classList.add('new-reading');
                setTimeout(() => {
                    element.parentElement.classList.remove('new-reading');
                }, 1000);
            } else {
                console.log(`❌ Element ${elementId} not found or value is ${value}`);
            }
        });

        // Update timestamp
        const timestampElement = document.getElementById('latest-timestamp');
        if (timestampElement) {
            const now = new Date();
            timestampElement.textContent = now.toLocaleTimeString();
            console.log('✅ Updated timestamp to:', now.toLocaleTimeString());
        }

        // Update reading status
        const statusElement = document.getElementById('reading-status');
        if (statusElement) {
            statusElement.textContent = 'Live Data';
            statusElement.className = 'badge bg-success';
            console.log('✅ Updated reading status to Live Data');
        }

        // Show data flow animation
        this.showDataFlowAnimation();
        console.log('✅ Latest Reading Box update completed');
    }

    showDataFlowAnimation() {
        const latestCard = document.getElementById('latest-reading-card');
        if (latestCard) {
            latestCard.classList.add('data-flow-indicator');
            setTimeout(() => {
                latestCard.classList.remove('data-flow-indicator');
            }, 2000);
        }
    }

    calculateTrend(oldValue, newValue) {
        if (oldValue === undefined) return 'stable';
        const diff = newValue - oldValue;
        const threshold = Math.abs(oldValue * 0.05); // 5% change threshold
        
        if (diff > threshold) return 'up';
        if (diff < -threshold) return 'down';
        return 'stable';
    }

    updateTrendIndicator(element, trend) {
        element.className = 'trend-indicator';
        
        switch (trend) {
            case 'up':
                element.innerHTML = '<i class="fas fa-arrow-up"></i>';
                element.classList.add('trend-up');
                break;
            case 'down':
                element.innerHTML = '<i class="fas fa-arrow-down"></i>';
                element.classList.add('trend-down');
                break;
            case 'stable':
                element.innerHTML = '<i class="fas fa-minus"></i>';
                element.classList.add('trend-stable');
                break;
        }
    }

    updateChart(data) {
        if (!this.chart) {
            console.log('Chart not initialized yet');
            return;
        }

        const now = new Date().toLocaleTimeString();
        
        // Add new data point to labels
        this.chart.data.labels.push(now);
        
        // Keep only last maxDataPoints
        if (this.chart.data.labels.length > this.maxDataPoints) {
            this.chart.data.labels.shift();
        }

        // Update datasets with proper sensor mapping
        const sensorMapping = {
            'mq2_gas': 0,
            'mq9_gas': 1,
            'temperature': 2,
            'humidity': 3,
            'noise': 4
        };

        Object.keys(sensorMapping).forEach(sensor => {
            const datasetIndex = sensorMapping[sensor];
            const value = data[sensor];
            
            if (value !== undefined && value !== null) {
                this.chart.data.datasets[datasetIndex].data.push(value);
                
                // Keep only last maxDataPoints
                if (this.chart.data.datasets[datasetIndex].data.length > this.maxDataPoints) {
                    this.chart.data.datasets[datasetIndex].data.shift();
                }
            }
        });

        // Update chart with animation
        this.chart.update('active');
        
        console.log('Chart updated with data:', data);
    }

    showAlert(alerts) {
        const alertBanner = document.getElementById('alert-banner');
        const alertContent = document.getElementById('alert-content');
        
        let alertHtml = '<ul class="mb-0">';
        alerts.forEach(alert => {
            alertHtml += `<li><strong>${alert.sensor.toUpperCase()}</strong>: ${alert.value} (Threshold: ${alert.threshold})</li>`;
        });
        alertHtml += '</ul>';
        
        alertContent.innerHTML = alertHtml;
        alertBanner.classList.remove('d-none');
        
        // Auto-hide after 10 seconds
        setTimeout(() => {
            alertBanner.classList.add('d-none');
        }, 10000);
    }

    updateConnectionStatus(connected, mqttConnected = null) {
        const statusElement = document.getElementById('connection-status');
        if (connected && (mqttConnected === null || mqttConnected)) {
            statusElement.textContent = 'Connected';
            statusElement.className = 'badge bg-success';
        } else if (connected && mqttConnected === false) {
            statusElement.textContent = 'WebSocket OK, MQTT Disconnected';
            statusElement.className = 'badge bg-warning';
        } else {
            statusElement.textContent = 'Disconnected';
            statusElement.className = 'badge bg-danger';
        }
    }

    updateMQTTStatus(connected, error = null) {
        const statusElement = document.getElementById('connection-status');
        const mqttStatusElement = document.getElementById('mqtt-status');
        
        if (connected) {
            statusElement.textContent = 'Connected to HiveMQ Cloud';
            statusElement.className = 'badge bg-success';
            if (mqttStatusElement) {
                mqttStatusElement.textContent = 'Connected';
                mqttStatusElement.className = 'text-success';
            }
        } else {
            statusElement.textContent = 'MQTT Disconnected';
            statusElement.className = 'badge bg-danger';
            if (mqttStatusElement) {
                mqttStatusElement.textContent = 'Disconnected';
                mqttStatusElement.className = 'text-danger';
            }
            if (error) {
                console.error('MQTT Error:', error);
            }
        }
    }

    updateMQTTStatusDisplay(connected) {
        const mqttStatusElement = document.getElementById('mqtt-status');
        if (mqttStatusElement) {
            if (connected) {
                mqttStatusElement.textContent = 'Connected';
                mqttStatusElement.className = 'text-success';
            } else {
                mqttStatusElement.textContent = 'Disconnected';
                mqttStatusElement.className = 'text-danger';
            }
        }
    }

    updateAlertStatus(sensor, data) {
        const alertStatusElement = document.getElementById(`${sensor}_alert-status`);
        if (alertStatusElement) {
            const alertKey = sensor === 'mq2_gas' ? 'mq2_alert' : 'mq9_alert';
            const alertValue = data[alertKey];
            
            if (alertValue === 1) {
                alertStatusElement.textContent = '⚠️ ALERT ACTIVE';
                alertStatusElement.className = 'alert-status alert-active';
            } else {
                alertStatusElement.textContent = '✅ CLEAR';
                alertStatusElement.className = 'alert-status alert-clear';
            }
        }
    }

    updateLastUpdateTime() {
        const lastUpdateElement = document.getElementById('last-update');
        lastUpdateElement.textContent = new Date().toLocaleTimeString();
    }

    populateHistoricalTable(data) {
        const tbody = document.getElementById('historical-table');
        tbody.innerHTML = '';
        
        data.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${new Date(row.timestamp).toLocaleString()}</td>
                <td>${row.mq2_gas ? row.mq2_gas.toFixed(1) : '--'}</td>
                <td>${row.mq9_gas ? row.mq9_gas.toFixed(1) : '--'}</td>
                <td>${row.temperature ? row.temperature.toFixed(1) : '--'}</td>
                <td>${row.humidity ? row.humidity.toFixed(1) : '--'}</td>
                <td>${row.noise ? row.noise.toFixed(1) : '--'}</td>
                <td><span class="badge ${row.mq2_alert ? 'bg-danger' : 'bg-success'}">${row.mq2_alert ? 'ALERT' : 'CLEAR'}</span></td>
                <td><span class="badge ${row.mq9_alert ? 'bg-danger' : 'bg-success'}">${row.mq9_alert ? 'ALERT' : 'CLEAR'}</span></td>
            `;
            tbody.appendChild(tr);
        });
    }

    initializeMQTTStatus() {
        // Set initial MQTT status
        const mqttStatusElement = document.getElementById('mqtt-status');
        if (mqttStatusElement) {
            mqttStatusElement.textContent = 'Checking...';
            mqttStatusElement.className = 'text-warning';
        }
    }

    setupEventListeners() {
        // Refresh historical data every 30 seconds
        setInterval(() => {
            this.loadHistoricalData();
        }, 30000);
        
        // Test connection every 10 seconds
        setInterval(() => {
            if (this.socket && this.socket.connected) {
                this.socket.emit('request_status');
            }
        }, 10000);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new MiningMonitor();
});
