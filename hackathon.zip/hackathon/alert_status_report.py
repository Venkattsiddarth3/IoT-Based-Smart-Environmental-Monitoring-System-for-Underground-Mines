#!/usr/bin/env python3
"""
Alert System Status Report
Shows the current status of all alert systems
"""

import os
from dotenv import load_dotenv

def check_alert_systems():
    """Check status of all alert systems"""
    print("🚨 ALERT SYSTEM STATUS REPORT")
    print("=" * 60)
    
    load_dotenv()
    
    # Email Alert Status
    print("📧 EMAIL ALERT SYSTEM")
    print("-" * 30)
    
    email_user = os.getenv('EMAIL_USER', '')
    email_password = os.getenv('EMAIL_PASSWORD', '')
    recipient_emails = os.getenv('RECIPIENT_EMAILS', '')
    
    print(f"✅ SMTP Server: {os.getenv('EMAIL_SMTP_SERVER', 'smtp.gmail.com')}")
    print(f"✅ SMTP Port: {os.getenv('EMAIL_SMTP_PORT', '587')}")
    print(f"✅ Email User: {email_user}")
    print(f"✅ Email Password: {'Configured' if email_password else 'Not set'}")
    print(f"✅ Recipients: {recipient_emails}")
    
    if email_user and email_password and recipient_emails:
        print("✅ Email alerts: CONFIGURED")
        print("📬 Will send to:")
        for recipient in recipient_emails.split(','):
            print(f"   • {recipient.strip()}")
    else:
        print("❌ Email alerts: NOT CONFIGURED")
    
    # Telegram Alert Status
    print("\n📱 TELEGRAM ALERT SYSTEM")
    print("-" * 30)
    
    telegram_token = os.getenv('TELEGRAM_BOT_TOKEN', '')
    telegram_chat_id = os.getenv('TELEGRAM_CHAT_ID', '')
    
    print(f"✅ Bot Token: {'Configured' if telegram_token else 'Not set'}")
    print(f"✅ Chat ID: {'Configured' if telegram_chat_id else 'Not set'}")
    
    if telegram_token and telegram_chat_id:
        print("✅ Telegram alerts: CONFIGURED")
        print("📱 Will send instant messages")
    else:
        print("❌ Telegram alerts: NOT CONFIGURED")
    
    # Web UI Alert Status
    print("\n🌐 WEB UI ALERT SYSTEM")
    print("-" * 30)
    print("✅ Visual alert banners: CONFIGURED")
    print("✅ Color-coded sensor cards: CONFIGURED")
    print("✅ Alert status indicators: CONFIGURED")
    print("✅ Real-time notifications: CONFIGURED")
    
    # Alert Features
    print("\n🎯 ALERT FEATURES")
    print("-" * 30)
    
    features = [
        "📧 Professional HTML email alerts",
        "📱 Instant Telegram notifications",
        "🌐 Visual web UI alerts",
        "🚨 Threshold breach detection",
        "⚠️ Emergency action recommendations",
        "📊 Sensor value vs threshold comparison",
        "🕐 Timestamp tracking",
        "📋 Multiple recipient support",
        "🎨 Color-coded alert levels",
        "📱 Mobile-friendly formats"
    ]
    
    for feature in features:
        print(f"   {feature}")
    
    # Alert Triggers
    print("\n🚨 ALERT TRIGGERS")
    print("-" * 30)
    
    thresholds = {
        'mq2_gas': 300,      # ppm - Methane, LPG, Propane
        'mq9_gas': 200,      # ppm - CO, LPG, CH4
        'temperature': 35,   # °C - High temperature
        'humidity': 80,      # % - High humidity
        'noise': 85          # dB - High noise level
    }
    
    for sensor, threshold in thresholds.items():
        print(f"   {sensor}: {threshold}")

def show_alert_examples():
    """Show examples of alert content"""
    print("\n📋 ALERT CONTENT EXAMPLES")
    print("-" * 30)
    
    print("📧 Email Alert Example:")
    print("   Subject: 🚨 DANGER ALERT - Underground Mining Environment")
    print("   Content: Professional HTML with sensor details, thresholds, and emergency actions")
    
    print("\n📱 Telegram Alert Example:")
    print("   🚨 DANGER ALERT - Underground Mining Environment")
    print("   ⚠️ MQ2_GAS: 450 (Threshold: 300)")
    print("   ⚠️ MQ9_GAS: 250 (Threshold: 200)")
    print("   Time: 2025-09-25 04:45:00")
    
    print("\n🌐 Web UI Alert Example:")
    print("   Visual banner with danger message")
    print("   Red alert indicators on sensor cards")
    print("   Auto-dismissing notifications")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("🚨 COMPREHENSIVE ALERT SYSTEM REPORT")
    print("=" * 60)
    
    check_alert_systems()
    show_alert_examples()
    
    print("\n" + "=" * 60)
    print("✅ ALERT SYSTEM STATUS SUMMARY")
    print("=" * 60)
    
    # Overall status
    email_configured = bool(os.getenv('EMAIL_USER') and os.getenv('EMAIL_PASSWORD'))
    telegram_configured = bool(os.getenv('TELEGRAM_BOT_TOKEN') and os.getenv('TELEGRAM_CHAT_ID'))
    
    print(f"📧 Email Alerts: {'✅ CONFIGURED' if email_configured else '⚠️ NEEDS SETUP'}")
    print(f"📱 Telegram Alerts: {'✅ CONFIGURED' if telegram_configured else '⚠️ NEEDS SETUP'}")
    print(f"🌐 Web UI Alerts: ✅ ALWAYS ACTIVE")
    
    if email_configured and telegram_configured:
        print("\n🎉 ALL ALERT SYSTEMS ARE CONFIGURED!")
        print("🚨 Your mining environment is fully protected with multi-channel alerts")
    elif telegram_configured:
        print("\n✅ Telegram alerts are working!")
        print("📧 Email alerts may need app password setup")
    else:
        print("\n⚠️ Some alert systems need configuration")
        print("📖 Check email_setup_guide.md for setup instructions")
    
    print("\n🚀 System is ready to monitor and alert!")

if __name__ == "__main__":
    main()
