#!/usr/bin/env python3
"""
Test script to verify the monitoring system connection
"""

import requests
import socketio
import time

def test_http_connection():
    """Test HTTP connection to the Flask server"""
    try:
        response = requests.get('http://localhost:5000', timeout=5)
        if response.status_code == 200:
            print("✅ HTTP connection successful")
            return True
        else:
            print(f"❌ HTTP connection failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ HTTP connection error: {e}")
        return False

def test_websocket_connection():
    """Test WebSocket connection"""
    try:
        sio = socketio.Client()
        
        @sio.event
        def connect():
            print("✅ WebSocket connection successful")
            sio.disconnect()
        
        @sio.event
        def disconnect():
            print("WebSocket disconnected")
        
        sio.connect('http://localhost:5000')
        time.sleep(2)
        return True
        
    except Exception as e:
        print(f"❌ WebSocket connection error: {e}")
        return False

def test_api_endpoints():
    """Test API endpoints"""
    endpoints = [
        '/api/current_data',
        '/api/historical_data', 
        '/api/thresholds'
    ]
    
    for endpoint in endpoints:
        try:
            response = requests.get(f'http://localhost:5000{endpoint}', timeout=5)
            if response.status_code == 200:
                print(f"✅ {endpoint} - OK")
            else:
                print(f"❌ {endpoint} - Failed: {response.status_code}")
        except Exception as e:
            print(f"❌ {endpoint} - Error: {e}")

def main():
    print("🔍 Testing Underground Mining Monitor Connection")
    print("=" * 50)
    
    # Test HTTP connection
    print("\n1. Testing HTTP Connection...")
    http_ok = test_http_connection()
    
    if http_ok:
        # Test API endpoints
        print("\n2. Testing API Endpoints...")
        test_api_endpoints()
        
        # Test WebSocket connection
        print("\n3. Testing WebSocket Connection...")
        websocket_ok = test_websocket_connection()
        
        if websocket_ok:
            print("\n🎉 All connections successful!")
            print("The monitoring system is working properly.")
        else:
            print("\n⚠️ WebSocket connection failed")
            print("Check if the server is running with socketio support")
    else:
        print("\n❌ HTTP connection failed")
        print("Make sure the server is running on http://localhost:5000")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    main()
