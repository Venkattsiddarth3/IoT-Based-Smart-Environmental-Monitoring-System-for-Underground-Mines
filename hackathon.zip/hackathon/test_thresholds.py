#!/usr/bin/env python3
"""
Test script to verify thresholds are working correctly
"""

import requests
import json

def test_thresholds():
    """Test the threshold API endpoint"""
    print("🧪 TESTING THRESHOLD SYSTEM")
    print("=" * 40)
    
    try:
        # Test the thresholds API
        response = requests.get('http://localhost:5001/api/thresholds')
        if response.status_code == 200:
            thresholds = response.json()
            print("✅ Thresholds API working!")
            print("\n📊 CURRENT THRESHOLDS:")
            for sensor, threshold in thresholds.items():
                print(f"   {sensor}: {threshold}")
            
            # Verify the thresholds match our optimized values
            expected_thresholds = {
                'mq2_gas': 50.0,
                'mq9_gas': 30.0,
                'temperature': 40.0,
                'humidity': 90.0,
                'noise': 50.0
            }
            
            print("\n🎯 THRESHOLD VERIFICATION:")
            all_correct = True
            for sensor, expected in expected_thresholds.items():
                actual = thresholds.get(sensor)
                if actual == expected:
                    print(f"   ✅ {sensor}: {actual} (Correct)")
                else:
                    print(f"   ❌ {sensor}: {actual} (Expected: {expected})")
                    all_correct = False
            
            if all_correct:
                print("\n🎉 ALL THRESHOLDS ARE CORRECT!")
            else:
                print("\n⚠️  SOME THRESHOLDS NEED UPDATING")
                
        else:
            print(f"❌ API Error: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

def test_current_data():
    """Test current data API"""
    print("\n📡 TESTING CURRENT DATA")
    print("=" * 30)
    
    try:
        response = requests.get('http://localhost:5001/api/current_data')
        if response.status_code == 200:
            data = response.json()
            print("✅ Current data API working!")
            print("\n📊 CURRENT SENSOR READINGS:")
            for sensor, value in data.items():
                print(f"   {sensor}: {value}")
        else:
            print(f"❌ API Error: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

def main():
    print("🏭 UNDERGROUND MINING MONITOR")
    print("🧪 THRESHOLD & DATA TESTING")
    print("=" * 50)
    
    test_thresholds()
    test_current_data()
    
    print("\n🌐 WEB UI ACCESS:")
    print("   URL: http://localhost:5001")
    print("   Features: Real-time data, Updated thresholds, Latest reading box")

if __name__ == "__main__":
    main()
